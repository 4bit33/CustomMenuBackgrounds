package com.cmb.custommenubackgrounds.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Small helper around {@link class_1043} so the individual
 * background renderers don't have to repeat texture registration /
 * upload / draw boilerplate. One instance owns exactly one GPU texture and
 * re-uploads its pixel buffer only when {@link #upload(class_1011)} is
 * called (i.e. once per decoded frame, never once per render call).
 */
public final class TextureUtil {

    private final class_2960 id;
    private class_1043 texture;
    private int width;
    private int height;

    public TextureUtil(String debugName) {
        this.id = class_2960.method_60655("custommenubackgrounds", "dynamic/" + debugName);
    }

    /** Uploads a freshly decoded frame. Takes ownership of {@code image} (will close it). */
    public void upload(class_1011 image) {
        class_310 client = class_310.method_1551();
        this.width = image.method_4307();
        this.height = image.method_4323();
        client.execute(() -> {
            if (texture == null) {
                texture = new class_1043(image);
                client.method_1531().method_4616(id, texture);
            } else {
                // Replace the backing image and re-upload just this texture's data.
                texture.method_4526(image);
                texture.method_4524();
            }
        });
    }

    public void drawRect(class_332 context, int x, int y, int width, int height, float brightness) {
        if (texture == null) {
            return;
        }
        RenderSystem.setShaderColor(brightness, brightness, brightness, 1.0f);
        context.method_25290(id, x, y, 0, 0, width, height, width, height);
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void close() {
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            if (texture != null) {
                client.method_1531().method_4615(id);
                texture = null;
            }
        });
    }
}
