package com.cmb.custommenubackgrounds.gui;


import com.cmb.custommenubackgrounds.CustomMenuBackgroundsClient;
import com.cmb.custommenubackgrounds.background.BackgroundManager;
import com.cmb.custommenubackgrounds.background.BackgroundType;
import com.cmb.custommenubackgrounds.background.ScaleMode;
import com.cmb.custommenubackgrounds.config.ConfigManager;
import com.cmb.custommenubackgrounds.config.ModConfig;
import com.cmb.custommenubackgrounds.gui.widget.LabeledSliderWidget;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5676;

/**
 * The mod's own settings menu, reachable from the title screen. All widgets
 * write into a working copy of {@link ModConfig}; "Preview" applies that
 * copy live (without touching disk), "Save" persists it, "Reset" discards
 * unsaved edits and reloads whatever is currently saved on disk.
 */
public class ModSettingsScreen extends class_437 {

    private final class_437 parent;
    private ModConfig working;

    public ModSettingsScreen(class_437 parent) {
        super(class_2561.method_43471("custommenubackgrounds.settings.title"));
        this.parent = parent;
        this.working = BackgroundManager.get().getConfig().copy();
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int y = 35;
        int rowHeight = 24;
        int colWidth = 155;
        int gap = 8;
        int totalWidth = colWidth * 2 + gap;

        int leftX = centerX - totalWidth / 2;
        int rightX = leftX + colWidth + gap;

        // --- ROW 1 ---
        // Left: Background type
        this.method_37063(class_5676.<BackgroundType>method_32606(type -> class_2561.method_43471(
                        "custommenubackgrounds.settings.type." + type.name().toLowerCase()))
                .method_32624(BackgroundType.values())
                .method_32619(BackgroundType.fromStringSafe(working.backgroundType))
                .method_32617(leftX, y, colWidth, 20,
                        class_2561.method_43471("custommenubackgrounds.settings.type"),
                        (button, value) -> {
                            working.backgroundType = value.name().toLowerCase();
                            working.background = "";
                            this.method_41843();
                        }));

        // Right: File picker (matches current type)
        this.method_37063(class_5676.<String>method_32606(name -> name.isEmpty()
                        ? class_2561.method_43471("custommenubackgrounds.settings.file.none")
                        : class_2561.method_43469("custommenubackgrounds.settings.file", name))
                .method_32620(availableFilesForCurrentType())
                .method_32619(working.background == null ? "" : working.background)
                .method_32617(rightX, y, colWidth, 20, class_2561.method_43473(),
                        (button, value) -> working.background = value));
        y += rowHeight;

        // --- ROW 2 ---
        // Left: Select / Import Background File (In-game File Browser)
        this.method_37063(class_4185.method_46430(
                class_2561.method_43471("custommenubackgrounds.settings.browse_file"),
                button -> openFilePicker(false)
        ).method_46434(leftX, y, colWidth, 20).method_46431());

        // Right: Scale mode
        this.method_37063(class_5676.<ScaleMode>method_32606(mode -> class_2561.method_43470(mode.name()))
                .method_32624(ScaleMode.values())
                .method_32619(ScaleMode.fromStringSafe(working.scaleMode))
                .method_32617(rightX, y, colWidth, 20,
                        class_2561.method_43471("custommenubackgrounds.settings.scale_mode"),
                        (button, value) -> working.scaleMode = value.name().toLowerCase()));
        y += rowHeight;

        // --- ROW 3 ---
        // Left: Brightness
        this.method_37063(new LabeledSliderWidget(leftX, y, colWidth, 20,
                0.0f, 2.0f, working.brightness,
                (prefix, v) -> class_2561.method_43469("custommenubackgrounds.settings.brightness", format(v)),
                v -> working.brightness = v));

        // Right: Overlay opacity
        this.method_37063(new LabeledSliderWidget(rightX, y, colWidth, 20,
                0.0f, 1.0f, working.overlayOpacity,
                (prefix, v) -> class_2561.method_43469("custommenubackgrounds.settings.overlay", format(v)),
                v -> working.overlayOpacity = v));
        y += rowHeight;

        // --- ROW 4 ---
        // Left: Playback / Video speed
        this.method_37063(new LabeledSliderWidget(leftX, y, colWidth, 20,
                0.1f, 3.0f, working.videoSpeed,
                (prefix, v) -> class_2561.method_43469("custommenubackgrounds.settings.speed", format(v)),
                v -> working.videoSpeed = v));

        // Right: Video volume
        this.method_37063(new LabeledSliderWidget(rightX, y, colWidth, 20,
                0.0f, 1.0f, working.videoVolume,
                (prefix, v) -> class_2561.method_43469("custommenubackgrounds.settings.volume", format(v)),
                v -> working.videoVolume = v));
        y += rowHeight;

        // --- ROW 5 ---
        // Left: Panorama rotation speed
        this.method_37063(new LabeledSliderWidget(leftX, y, colWidth, 20,
                0.0f, 3.0f, working.panoramaRotationSpeed,
                (prefix, v) -> class_2561.method_43469("custommenubackgrounds.settings.panorama_speed", format(v)),
                v -> working.panoramaRotationSpeed = v));

        // Right: Custom music toggle
        this.method_37063(class_5676.method_32613(working.customMusicEnabled)
                .method_32617(rightX, y, colWidth, 20,
                        class_2561.method_43471("custommenubackgrounds.settings.music_enabled"),
                        (button, value) -> working.customMusicEnabled = value));
        y += rowHeight;

        // --- ROW 6 ---
        // Left: Custom music file picker
        this.method_37063(class_5676.<String>method_32606(name -> name.isEmpty()
                        ? class_2561.method_43471("custommenubackgrounds.settings.file.none")
                        : class_2561.method_43469("custommenubackgrounds.settings.file", name))
                .method_32620(availableFilesIn(ConfigManager.MUSIC_DIR, ".ogg"))
                .method_32619(working.customMusicFile == null ? "" : working.customMusicFile)
                .method_32617(leftX, y, colWidth, 20, class_2561.method_43473(),
                        (button, value) -> working.customMusicFile = value));

        // Right: Select / Import Music File (In-game File Browser)
        this.method_37063(class_4185.method_46430(
                class_2561.method_43471("custommenubackgrounds.settings.browse_music"),
                button -> openFilePicker(true)
        ).method_46434(rightX, y, colWidth, 20).method_46431());
        y += rowHeight;

        // --- ROW 7 ---
        // Left: Custom music volume
        this.method_37063(new LabeledSliderWidget(leftX, y, colWidth, 20,
                0.0f, 1.0f, working.customMusicVolume,
                (prefix, v) -> class_2561.method_43469("custommenubackgrounds.settings.music_volume", format(v)),
                v -> working.customMusicVolume = v));

        // Right: Open resource folder
        this.method_37063(class_4185.method_46430(
                class_2561.method_43471("custommenubackgrounds.settings.open_folder"),
                button -> class_156.method_668().method_672(ConfigManager.RESOURCE_ROOT.toFile())
        ).method_46434(rightX, y, colWidth, 20).method_46431());
        y += rowHeight + 6;

        // --- BOTTOM CONTROLS ---
        // Preview / Reset / Save row
        int buttonWidth = (totalWidth - 8) / 3;
        this.method_37063(class_4185.method_46430(
                class_2561.method_43471("custommenubackgrounds.settings.preview"),
                button -> BackgroundManager.get().previewConfig(working.copy())
        ).method_46434(leftX, y, buttonWidth, 20).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43471("custommenubackgrounds.settings.reset"),
                button -> {
                    BackgroundManager.get().revertToSaved();
                    this.working = BackgroundManager.get().getConfig().copy();
                    this.method_41843();
                }
        ).method_46434(leftX + buttonWidth + 4, y, buttonWidth, 20).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43471("custommenubackgrounds.settings.save"),
                button -> {
                    BackgroundManager.get().applyConfig(working.copy());
                    CustomMenuBackgroundsClient.refreshMusic();
                    this.method_25419();
                }
        ).method_46434(leftX + 2 * (buttonWidth + 4), y, buttonWidth, 20).method_46431());
        y += rowHeight + 4;

        // Done / back
        this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> this.method_25419())
                .method_46434(centerX - 100, y, 200, 20).method_46431());
    }

    private void openFilePicker(boolean isMusic) {
        BackgroundType type = BackgroundType.fromStringSafe(working.backgroundType);
        Path targetDir = isMusic ? ConfigManager.MUSIC_DIR : switch (type) {
            case VIDEO -> ConfigManager.VIDEOS_DIR;
            case GIF, STATIC_IMAGE -> ConfigManager.IMAGES_DIR;
            default -> ConfigManager.IMAGES_DIR;
        };

        String[] ext = isMusic
                ? new String[]{".ogg"}
                : switch (type) {
                    case VIDEO -> new String[]{".webm", ".mp4"};
                    case GIF -> new String[]{".gif"};
                    case STATIC_IMAGE -> new String[]{".png", ".jpg", ".jpeg", ".webp"};
                    default -> new String[]{".png", ".jpg", ".jpeg", ".webp"};
                };

        class_310.method_1551().method_1507(new InGameFilePickerScreen(
                this,
                targetDir,
                ext,
                fileName -> {
                    if (isMusic) {
                        working.customMusicFile = fileName;
                    } else {
                        working.background = fileName;
                    }
                    BackgroundManager.get().previewConfig(working.copy());
                    this.method_41843();
                }
        ));
    }

    protected void method_41843() {
        this.method_37067();
        this.method_25426();
    }

    private List<String> availableFilesForCurrentType() {
        BackgroundType type = BackgroundType.fromStringSafe(working.backgroundType);
        return switch (type) {
            case VIDEO -> availableFilesIn(ConfigManager.VIDEOS_DIR, ".webm", ".mp4");
            case GIF -> availableFilesIn(ConfigManager.IMAGES_DIR, ".gif");
            case STATIC_IMAGE -> availableFilesIn(ConfigManager.IMAGES_DIR, ".png", ".jpg", ".jpeg", ".webp");
            default -> List.of("");
        };
    }

    private static List<String> availableFilesIn(Path dir, String... extensions) {
        try (Stream<Path> stream = Files.list(dir)) {
            List<String> names = stream
                    .filter(Files::isRegularFile)
                    .map(p -> p.getFileName().toString())
                    .filter(name -> {
                        String lower = name.toLowerCase();
                        for (String ext : extensions) {
                            if (lower.endsWith(ext)) return true;
                        }
                        return false;
                    })
                    .collect(Collectors.toList());
            names.add(0, "");
            return names;
        } catch (IOException e) {
            return List.of("");
        }
    }

    private static String format(float v) {
        return String.format("%.2f", v);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0x60000000);
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 15, 0xFFFFFF);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(parent);
    }
}
