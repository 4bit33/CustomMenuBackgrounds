package com.cmb.custommenubackgrounds.gui.widget;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_357;

/**
 * A vanilla {@link class_357} that maps its internal 0..1 double onto an
 * arbitrary [min, max] float range and formats its own label, so every
 * numeric setting in {@link com.cmb.custommenubackgrounds.gui.ModSettingsScreen}
 * doesn't need its own subclass.
 */
public class LabeledSliderWidget extends class_357 {

    private final float min;
    private final float max;
    private final BiFunction<String, Float, class_2561> labelFormatter;
    private final Consumer<Float> onChange;

    public LabeledSliderWidget(int x, int y, int width, int height,
                                float min, float max, float initialValue,
                                BiFunction<String, Float, class_2561> labelFormatter,
                                Consumer<Float> onChange) {
        super(x, y, width, height, class_2561.method_43473(), normalize(initialValue, min, max));
        this.min = min;
        this.max = max;
        this.labelFormatter = labelFormatter;
        this.onChange = onChange;
        method_25346();
    }

    private static double normalize(float value, float min, float max) {
        return (value - min) / (max - min);
    }

    public float currentValue() {
        return (float) (min + field_22753 * (max - min));
    }

    @Override
    protected void method_25346() {
        method_25355(labelFormatter.apply("", currentValue()));
    }

    @Override
    protected void method_25344() {
        onChange.accept(currentValue());
    }
}
