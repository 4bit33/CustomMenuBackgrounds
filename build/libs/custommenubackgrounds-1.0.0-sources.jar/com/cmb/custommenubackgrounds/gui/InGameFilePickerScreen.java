package com.cmb.custommenubackgrounds.gui;

import com.cmb.custommenubackgrounds.config.ConfigManager;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_5244;

/**
 * An in-game file browser screen that lets users select and import background
 * and music files directly inside Minecraft's UI without depending on OS
 * window focus or external file dialogs.
 */
public class InGameFilePickerScreen extends class_437 {

    private final class_437 parent;
    private final Path destinationDir;
    private final String[] extensions;
    private final Consumer<String> onSelected;

    private Path currentDir;
    private FileListWidget listWidget;
    private Path selectedPath;

    public InGameFilePickerScreen(class_437 parent, Path destinationDir, String[] extensions, Consumer<String> onSelected) {
        super(class_2561.method_43471("custommenubackgrounds.picker.title"));
        this.parent = parent;
        this.destinationDir = destinationDir;
        this.extensions = extensions;
        this.onSelected = onSelected;

        Path home = Paths.get(System.getProperty("user.home"));
        Path downloads = home.resolve("Downloads");
        if (Files.exists(downloads)) {
            this.currentDir = downloads;
        } else {
            this.currentDir = destinationDir;
        }
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;

        // Quick jump toolbar
        int y = 30;
        int btnW = 74;
        int gap = 4;
        int startX = centerX - (btnW * 5 + gap * 4) / 2;

        this.method_37063(class_4185.method_46430(class_2561.method_43470(".. (Up)"), b -> navigateUp())
                .method_46434(startX, y, btnW, 20).method_46431());

        Path home = Paths.get(System.getProperty("user.home"));
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Downloads"), b -> setDir(home.resolve("Downloads")))
                .method_46434(startX + (btnW + gap), y, btnW, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Pictures"), b -> setDir(home.resolve("Pictures")))
                .method_46434(startX + (btnW + gap) * 2, y, btnW, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Desktop"), b -> setDir(home.resolve("Desktop")))
                .method_46434(startX + (btnW + gap) * 3, y, btnW, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Mod Folder"), b -> setDir(destinationDir))
                .method_46434(startX + (btnW + gap) * 4, y, btnW, 20).method_46431());

        // File List Widget (y=55 to height-40)
        this.listWidget = new FileListWidget(this.field_22787, this.field_22789, this.field_22790 - 95, 55, 20);
        this.method_25429(this.listWidget);
        populateList();

        // Bottom actions
        int bottomY = this.field_22790 - 35;
        int actionW = 110;
        int actionStartX = centerX - (actionW * 3 + gap * 2) / 2;

        this.method_37063(class_4185.method_46430(class_2561.method_43471("custommenubackgrounds.picker.select"), b -> confirmSelection())
                .method_46434(actionStartX, bottomY, actionW, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43471("custommenubackgrounds.picker.system"), b -> openSystemDialog())
                .method_46434(actionStartX + actionW + gap, bottomY, actionW, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_5244.field_24335, b -> this.method_25419())
                .method_46434(actionStartX + (actionW + gap) * 2, bottomY, actionW, 20).method_46431());
    }

    private void navigateUp() {
        if (currentDir.getParent() != null) {
            setDir(currentDir.getParent());
        }
    }

    private void setDir(Path newDir) {
        if (newDir != null && Files.exists(newDir) && Files.isDirectory(newDir)) {
            this.currentDir = newDir;
            this.selectedPath = null;
            populateList();
        }
    }

    private void populateList() {
        if (this.listWidget == null) return;
        this.listWidget.method_25396().clear();

        try {
            File currentFile = currentDir.toFile();
            File[] files = currentFile.listFiles();
            if (files != null) {
                Arrays.sort(files, Comparator.comparing(File::isFile).thenComparing(File::getName, String.CASE_INSENSITIVE_ORDER));
                for (File f : files) {
                    if (f.isDirectory()) {
                        this.listWidget.method_25396().add(new FileEntry(f.toPath(), true));
                    } else if (matchesExtension(f.getName())) {
                        this.listWidget.method_25396().add(new FileEntry(f.toPath(), false));
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[CustomMenuBackgrounds] Error reading directory: " + e.getMessage());
        }
    }

    private boolean matchesExtension(String name) {
        String lower = name.toLowerCase();
        for (String ext : extensions) {
            if (lower.endsWith(ext.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    private void confirmSelection() {
        if (selectedPath == null) return;
        try {
            if (Files.isDirectory(selectedPath)) {
                setDir(selectedPath);
                return;
            }
            Path dest = destinationDir.resolve(selectedPath.getFileName().toString());
            if (!selectedPath.equals(dest)) {
                Files.copy(selectedPath, dest, StandardCopyOption.REPLACE_EXISTING);
            }
            onSelected.accept(selectedPath.getFileName().toString());
            this.method_25419();
        } catch (Exception e) {
            System.err.println("[CustomMenuBackgrounds] Failed to copy selected file: " + e.getMessage());
        }
    }

    private void openSystemDialog() {
        java.awt.EventQueue.invokeLater(() -> {
            try {
                javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
                javax.swing.JFileChooser chooser = new javax.swing.JFileChooser();
                chooser.setCurrentDirectory(currentDir.toFile());
                int result = chooser.showOpenDialog(null);
                if (result == javax.swing.JFileChooser.APPROVE_OPTION && chooser.getSelectedFile() != null) {
                    File f = chooser.getSelectedFile();
                    class_310.method_1551().execute(() -> {
                        selectedPath = f.toPath();
                        confirmSelection();
                    });
                }
            } catch (Exception e) {
                System.err.println("[CustomMenuBackgrounds] System chooser failed: " + e.getMessage());
            }
        });
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Перевизначаємо щоб вимкнути ванільний blur 1.21.1 - провідник був заблюрений
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Не викликаємо ванільний blur, малюємо свій напівпрозорий фон
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xDD121420);
        if (this.listWidget != null) {
            this.listWidget.method_25394(context, mouseX, mouseY, delta);
        }
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 8, 0xFFFFFF);
        String pathStr = currentDir.toString();
        if (pathStr.length() > 60) {
            pathStr = "..." + pathStr.substring(pathStr.length() - 57);
        }
        context.method_27534(this.field_22793, class_2561.method_43470(pathStr), this.field_22789 / 2, 20, 0xAAAAAA);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(parent);
    }

    // --- LIST WIDGET & ENTRIES ---
    private class FileListWidget extends class_4280<FileEntry> {
        public FileListWidget(class_310 client, int width, int height, int top, int itemHeight) {
            super(client, width, height, top, itemHeight);
        }

        @Override
        public int method_25322() {
            return this.field_22758 - 40;
        }
    }

    private class FileEntry extends class_4280.class_4281<FileEntry> {
        final Path path;
        final boolean isDir;
        final String displayName;
        private long lastClickTime = 0;

        FileEntry(Path path, boolean isDir) {
            this.path = path;
            this.isDir = isDir;
            this.displayName = isDir ? "📁  " + path.getFileName().toString() + "/" : "📄  " + path.getFileName().toString();
        }

        @Override
        public void method_25343(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            boolean isSelected = selectedPath != null && selectedPath.equals(path);
            int color = isSelected ? 0xFFFFA0 : (isDir ? 0x88EEFF : 0xFFFFFF);
            if (hovered) {
                context.method_25294(x, y, x + entryWidth, y + entryHeight, 0x33FFFFFF);
            }
            context.method_25303(field_22793, displayName, x + 5, y + 5, color);
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            selectedPath = path;
            long now = System.currentTimeMillis();
            if (now - lastClickTime < 300) {
                confirmSelection();
                return true;
            }
            lastClickTime = now;
            return true;
        }

        public class_2561 method_37006() {
            return class_2561.method_43470(displayName);
        }
    }
}
