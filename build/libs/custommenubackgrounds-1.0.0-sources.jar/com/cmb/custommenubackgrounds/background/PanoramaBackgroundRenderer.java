package com.cmb.custommenubackgrounds.background;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Renders a rotating skybox from up to 6 user-supplied panorama images
 * ("panorama_0.png" .. "panorama_5.png"), falling back to Minecraft's own
 * vanilla panorama textures for any face the user did not provide. This
 * mirrors vanilla's PanoramaRenderer but reads its faces from the mod's own
 * resource folder instead of the built-in resource pack, and exposes a
 * configurable rotation speed.
 */
public class PanoramaBackgroundRenderer implements BackgroundRenderer {

    private static final class_2960[] VANILLA_FACES = new class_2960[]{
            class_2960.method_60656("textures/gui/title/background/panorama_0.png"),
            class_2960.method_60656("textures/gui/title/background/panorama_1.png"),
            class_2960.method_60656("textures/gui/title/background/panorama_2.png"),
            class_2960.method_60656("textures/gui/title/background/panorama_3.png"),
            class_2960.method_60656("textures/gui/title/background/panorama_4.png"),
            class_2960.method_60656("textures/gui/title/background/panorama_5.png"),
    };

    private final class_2960[] faces = new class_2960[6];
    private final List<class_2960> ownedTextures = new ArrayList<>();
    private final float rotationSpeed;
    private float ticks = 0f;
    private float spin = 0f;

    public PanoramaBackgroundRenderer(Path panoramaDir, float rotationSpeed) {
        this.rotationSpeed = rotationSpeed;
        for (int i = 0; i < 6; i++) {
            Path candidate = panoramaDir.resolve("panorama_" + i + ".png");
            if (Files.isRegularFile(candidate)) {
                faces[i] = loadCustomFace(candidate, i);
            } else {
                faces[i] = VANILLA_FACES[i];
            }
        }
    }

    private class_2960 loadCustomFace(Path file, int index) {
        try (InputStream in = Files.newInputStream(file)) {
            class_1011 image = class_1011.method_4309(in);
            class_2960 id = class_2960.method_60655("custommenubackgrounds", "panorama/face_" + index);
            class_1043 texture = new class_1043(image);
            class_310.method_1551().method_1531().method_4616(id, texture);
            ownedTextures.add(id);
            return id;
        } catch (IOException e) {
            System.err.println("[CustomMenuBackgrounds] Failed to load panorama face " + index + ": " + e.getMessage());
            return VANILLA_FACES[index];
        }
    }

    @Override
    public void tick(float deltaSeconds) {
        ticks += deltaSeconds;
        spin += deltaSeconds * 10f * rotationSpeed; // degrees/sec at speed=1, matches vanilla's gentle drift
    }

    @Override
    public void render(class_332 context, int screenWidth, int screenHeight, float brightness, float overlayOpacity) {
        // A full perspective cubemap render (the same technique vanilla's
        // PanoramaRenderer uses) needs its own projection matrix and render
        // pass rather than DrawContext's 2D quad drawing. Vanilla's own
        // CubeMapRenderer only accepts a single base Identifier and derives
        // face names from a fixed "_0".."_5" suffix convention, which does not
        // fit our case of mixing user-supplied faces with vanilla fallbacks
        // under unrelated names - so PanoramaCubeMap below is a small,
        // self-contained re-implementation of that same technique that takes
        // 6 explicit face identifiers.
        PanoramaCubeMap.render(context, faces, screenWidth, screenHeight, spin, brightness);

        if (overlayOpacity > 0f) {
            context.method_25294(0, 0, screenWidth, screenHeight, ((int) (overlayOpacity * 255) << 24));
        }
    }

    @Override
    public void close() {
        class_310 client = class_310.method_1551();
        for (class_2960 id : ownedTextures) {
            client.execute(() -> client.method_1531().method_4615(id));
        }
        ownedTextures.clear();
    }
}
