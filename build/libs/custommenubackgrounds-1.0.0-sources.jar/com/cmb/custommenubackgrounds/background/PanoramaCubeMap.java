package com.cmb.custommenubackgrounds.background;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.joml.Matrix4f;

/**
 * Draws a six-face rotating cube map, the same visual technique vanilla's
 * title screen panorama uses, but with an explicit list of face identifiers
 * (rather than vanilla's single-base-name convention) so the mod can mix
 * user-supplied faces with vanilla fallbacks per-face, and an
 * externally-controlled rotation angle so it can be driven by the mod's
 * "panorama rotation speed" setting instead of the system clock.
 *
 * Face order (matching vanilla's panorama_0..5): +X, -X, +Y (top), -Y
 * (bottom), +Z, -Z, viewed from inside the cube.
 */
final class PanoramaCubeMap {

    private static final float NEAR = 0.05f;
    private static final float FAR = 10.0f;

    private PanoramaCubeMap() {
    }

    static void render(class_332 context, class_2960[] faces, int screenWidth, int screenHeight, float spinDegrees, float brightness) {
        class_4587 matrices = context.method_51448();
        matrices.method_22903();

        // Slight constant pitch, like vanilla's panorama, so the horizon isn't dead-center.
        float pitch = 15.0f;
        float yaw = spinDegrees % 360.0f;

        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(515); // GL_LEQUAL
        RenderSystem.setShaderColor(brightness, brightness, brightness, 1.0f);

        Matrix4f projection = new Matrix4f().perspective(
                (float) Math.toRadians(90.0f),
                (float) screenWidth / (float) screenHeight,
                NEAR, FAR);
        RenderSystem.backupProjectionMatrix();
        RenderSystem.setProjectionMatrix(projection, net.minecraft.class_8251.field_43360);

        matrices.method_34426();
        matrices.method_22907(new org.joml.Quaternionf().rotationX((float) Math.toRadians(pitch)));
        matrices.method_22907(new org.joml.Quaternionf().rotationY((float) Math.toRadians(yaw)));

        for (int face = 0; face < 6; face++) {
            drawFace(matrices, faces[face], face);
        }

        RenderSystem.restoreProjectionMatrix();
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.disableDepthTest();
        matrices.method_22909();
    }

    private static void drawFace(class_4587 matrices, class_2960 texture, int face) {
        RenderSystem.setShaderTexture(0, texture);
        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1585);

        matrices.method_22903();
        switch (face) {
            case 0 -> matrices.method_22907(new org.joml.Quaternionf().rotationY((float) Math.toRadians(90)));
            case 1 -> matrices.method_22907(new org.joml.Quaternionf().rotationY((float) Math.toRadians(-90)));
            case 2 -> matrices.method_22907(new org.joml.Quaternionf().rotationX((float) Math.toRadians(-90)));
            case 3 -> matrices.method_22907(new org.joml.Quaternionf().rotationX((float) Math.toRadians(90)));
            case 4 -> { /* front face, no extra rotation */ }
            case 5 -> matrices.method_22907(new org.joml.Quaternionf().rotationY((float) Math.toRadians(180)));
        }

        Matrix4f model = matrices.method_23760().method_23761();
        float d = 1.0f;
        buffer.method_22918(model, -d, -d, -d).method_22913(0, 0);
        buffer.method_22918(model, -d, d, -d).method_22913(0, 1);
        buffer.method_22918(model, d, d, -d).method_22913(1, 1);
        buffer.method_22918(model, d, -d, -d).method_22913(1, 0);

        class_286.method_43433(buffer.method_60800());
        matrices.method_22909();
    }
}
