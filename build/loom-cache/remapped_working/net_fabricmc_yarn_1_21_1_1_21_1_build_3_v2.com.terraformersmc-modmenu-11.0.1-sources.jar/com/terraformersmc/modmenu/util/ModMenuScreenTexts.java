package com.terraformersmc.modmenu.util;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5244;

public final class ModMenuScreenTexts {
	public static final class_2561 CONFIGURE = class_2561.method_43471("modmenu.configure");
	public static final class_2561 DROP_CONFIRM = class_2561.method_43471("modmenu.dropConfirm");
	public static final class_2561 DROP_INFO_LINE_1 = class_2561.method_43471("modmenu.dropInfo.line1");
	public static final class_2561 DROP_INFO_LINE_2 = class_2561.method_43471("modmenu.dropInfo.line2");
	public static final class_2561 DROP_SUCCESSFUL_LINE_1 = class_2561.method_43471("modmenu.dropSuccessful.line1");
	public static final class_2561 DROP_SUCCESSFUL_LINE_2 = class_2561.method_43471("modmenu.dropSuccessful.line2");
	public static final class_2561 ISSUES = class_2561.method_43471("modmenu.issues");
	public static final class_2561 MODS_FOLDER = class_2561.method_43471("modmenu.modsFolder");
	public static final class_2561 SEARCH = class_2561.method_43471("modmenu.search");
	public static final class_2561 TITLE = class_2561.method_43471("modmenu.title");
	public static final class_2561 TOGGLE_FILTER_OPTIONS = class_2561.method_43471("modmenu.toggleFilterOptions");
	public static final class_2561 WEBSITE = class_2561.method_43471("modmenu.website");

	private ModMenuScreenTexts() {
	}

	public static class_2561 modIdTooltip(String modId) {
		return class_2561.method_43469("modmenu.modIdToolTip", modId);
	}

	public static class_2561 configureError(String modId, Throwable e) {
		return class_2561.method_43469("modmenu.configure.error", modId, modId)
			.method_10852(class_5244.field_33849)
			.method_10852(class_5244.field_33849)
			.method_27693(e.toString())
			.method_27692(class_124.field_1061);
	}
}
