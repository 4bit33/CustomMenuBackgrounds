package com.terraformersmc.modmenu.mixin;

import com.terraformersmc.modmenu.api.ModMenuApi;
import com.terraformersmc.modmenu.config.ModMenuConfig;
import com.terraformersmc.modmenu.event.ModMenuEventHandler;
import com.terraformersmc.modmenu.gui.ModsScreen;
import com.terraformersmc.modmenu.gui.widget.ModMenuButtonWidget;
import com.terraformersmc.modmenu.gui.widget.UpdateCheckerTexturedButtonWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_433;
import net.minecraft.class_437;
import net.minecraft.class_7845;
import net.minecraft.class_8021;

@Mixin(class_433.class)
public abstract class MixinGameMenu extends class_437 {
	protected MixinGameMenu(class_2561 title) {
		super(title);
	}

	@Inject(method = "initWidgets", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/widget/GridWidget;forEachChild(Ljava/util/function/Consumer;)V"), locals = LocalCapture.CAPTURE_FAILEXCEPTION)
	private void onInitWidgets(CallbackInfo ci, class_7845 gridWidget, class_7845.class_7939 adder, class_2561 text) {
		if (gridWidget != null) {
			final List<class_8021> buttons = ((AccessorGridWidget) gridWidget).getChildren();
			if (ModMenuConfig.MODIFY_GAME_MENU.getValue()) {
				int modsButtonIndex = -1;
				final int spacing = 24;
				int buttonsY = this.field_22790 / 4 + 8;
				ModMenuConfig.GameMenuButtonStyle style = ModMenuConfig.GAME_MENU_BUTTON_STYLE.getValue();
				int vanillaButtonsY = this.field_22790 / 4 + 72 - 16 + 1;
				final int fullWidthButton = 204;

				for (int i = 0; i < buttons.size(); i++) {
					class_8021 widget = buttons.get(i);
					if (style == ModMenuConfig.GameMenuButtonStyle.INSERT) {
						if (!(widget instanceof class_339 button) || button.field_22764) {
							ModMenuEventHandler.shiftButtons(widget, modsButtonIndex == -1 || ModMenuEventHandler.buttonHasText(widget, "menu.reportBugs", "menu.server_links"), spacing);
							if (modsButtonIndex == -1) {
								buttonsY = widget.method_46427();
							}
						}
					}
					boolean isShortFeedback = ModMenuEventHandler.buttonHasText(widget, "menu.feedback");
					boolean isLongFeedback = ModMenuEventHandler.buttonHasText(widget, "menu.sendFeedback");

					if (isShortFeedback || isLongFeedback) {
						modsButtonIndex = i + 1;
						vanillaButtonsY = widget.method_46427();
						if (style == ModMenuConfig.GameMenuButtonStyle.REPLACE) {
							buttons.set(i, new ModMenuButtonWidget(
								widget.method_46426(),
								widget.method_46427(),
								isShortFeedback ? widget.method_25368() : fullWidthButton,
								widget.method_25364(),
								ModMenuApi.createModsButtonText(),
								this
							));
							buttons.stream()
								.filter(w -> ModMenuEventHandler.buttonHasText(w, "menu.reportBugs"))
								.forEach(w -> {
									if (w instanceof class_339 cw) {
										cw.field_22764 = false;
										cw.field_22763 = false;
									}
								});
						} else {
							modsButtonIndex = i + 1;
							if (!(widget instanceof class_339 button) || button.field_22764) {
								buttonsY = widget.method_46427();
							}
						}
					}
				}
				if (modsButtonIndex != -1) {
					if (style == ModMenuConfig.GameMenuButtonStyle.INSERT) {
						buttons.add(modsButtonIndex, new ModMenuButtonWidget(
							this.field_22789 / 2 - 102,
							buttonsY + spacing,
							fullWidthButton,
							20,
							ModMenuApi.createModsButtonText(),
							this
						));
					} else if (style == ModMenuConfig.GameMenuButtonStyle.ICON) {
						buttons.add(modsButtonIndex, new UpdateCheckerTexturedButtonWidget(
							this.field_22789 / 2 + 4 + 100 + 2,
							vanillaButtonsY,
							20,
							20,
							0,
							0,
							20,
							ModMenuEventHandler.MODS_BUTTON_TEXTURE,
							32,
							64,
							button -> class_310.method_1551().method_1507(new ModsScreen(this)),
							ModMenuApi.createModsButtonText()
						));
					}
				}
			}
		}
	}
}
