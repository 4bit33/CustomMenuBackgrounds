package com.terraformersmc.modmenu.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_7845;
import net.minecraft.class_8021;

@Mixin(class_7845.class)
public interface AccessorGridWidget {
	@Accessor
	List<class_8021> getChildren();
}
