package com.terraformersmc.modmenu.gui;

import com.terraformersmc.modmenu.ModMenu;
import com.terraformersmc.modmenu.config.ModMenuConfig;
import com.terraformersmc.modmenu.config.ModMenuConfigManager;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_4667;

public class ModMenuOptionsScreen extends class_4667 {

	public ModMenuOptionsScreen(class_437 previous) {
		super(previous, class_310.method_1551().field_1690, class_2561.method_43471("modmenu.options"));
	}

	@Override
	protected void method_60325() {
		if (this.field_51824 != null) {
			this.field_51824.method_20408(ModMenuConfig.asOptions());
		}
	}

	@Override
	public void method_25432() {
		ModMenuConfigManager.save();
		ModMenu.checkForUpdates();
	}
}
