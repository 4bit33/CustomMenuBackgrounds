package com.terraformersmc.modmenu.gui.widget;

import com.mojang.blaze3d.systems.RenderSystem;
import com.terraformersmc.modmenu.ModMenu;
import com.terraformersmc.modmenu.config.ModMenuConfig;
import com.terraformersmc.modmenu.gui.ModsScreen;
import com.terraformersmc.modmenu.gui.widget.entries.ChildEntry;
import com.terraformersmc.modmenu.gui.widget.entries.IndependentEntry;
import com.terraformersmc.modmenu.gui.widget.entries.ModListEntry;
import com.terraformersmc.modmenu.gui.widget.entries.ParentEntry;
import com.terraformersmc.modmenu.util.mod.Mod;
import com.terraformersmc.modmenu.util.mod.ModSearch;
import com.terraformersmc.modmenu.util.mod.fabric.FabricIconHandler;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4280;
import net.minecraft.class_757;
import net.minecraft.class_9801;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.stream.Collectors;

public class ModListWidget extends class_4280<ModListEntry> implements AutoCloseable {
	public static final boolean DEBUG = Boolean.getBoolean("modmenu.debug");
	private final ModsScreen parent;
	private List<Mod> mods = null;
	private final Set<Mod> addedMods = new HashSet<>();
	private String selectedModId = null;
	private boolean scrolling;
	private final FabricIconHandler iconHandler = new FabricIconHandler();

	public ModListWidget(
		class_310 client,
		int width,
		int height,
		int y,
		int itemHeight,
		ModListWidget list,
		ModsScreen parent
	) {
		super(client, width, height, y, itemHeight);
		this.parent = parent;
		if (list != null) {
			this.mods = list.mods;
		}
	}

	@Override
	public void method_25307(double amount) {
		super.method_25307(amount);
		int denominator = Math.max(0, this.method_25317() - (this.method_55443() - this.method_46427() - 4));
		if (denominator <= 0) {
			parent.updateScrollPercent(0);
		} else {
			parent.updateScrollPercent(method_25341() / Math.max(
				0,
				this.method_25317() - (this.method_55443() - this.method_46427() - 4)
			));
		}
	}

	@Override
	public boolean method_25370() {
		return parent.method_25399() == this;
	}

	public void select(ModListEntry entry) {
		this.setSelected(entry);
		if (entry != null) {
			Mod mod = entry.getMod();
			this.field_22740.method_44713()
				.method_19788(class_2561.method_43469("narrator.select", mod.getTranslatedName()).getString());
		}
	}

	@Override
	public void setSelected(ModListEntry entry) {
		super.method_25313(entry);
		selectedModId = entry.getMod().getId();
		parent.updateSelectedEntry(method_25334());
	}

	@Override
	protected boolean method_25332(int index) {
		ModListEntry selected = method_25334();
		return selected != null && selected.getMod().getId().equals(method_25326(index).getMod().getId());
	}

	@Override
	public int addEntry(ModListEntry entry) {
		if (addedMods.contains(entry.mod)) {
			return 0;
		}
		addedMods.add(entry.mod);
		int i = super.method_25321(entry);
		if (entry.getMod().getId().equals(selectedModId)) {
			setSelected(entry);
		}
		return i;
	}

	@Override
	protected boolean removeEntry(ModListEntry entry) {
		addedMods.remove(entry.mod);
		return super.method_25330(entry);
	}

	@Override
	protected ModListEntry method_25338(int index) {
		addedMods.remove(method_25326(index).mod);
		return super.method_25338(index);
	}

	public void reloadFilters() {
		filter(parent.getSearchInput(), true, false);
	}


	public void filter(String searchTerm, boolean refresh) {
		filter(searchTerm, refresh, true);
	}

	private boolean hasVisibleChildMods(Mod parent) {
		List<Mod> children = ModMenu.PARENT_MAP.get(parent);
		boolean hideLibraries = !ModMenuConfig.SHOW_LIBRARIES.getValue();

		return !children.stream()
			.allMatch(child -> child.isHidden() || hideLibraries && child.getBadges().contains(Mod.Badge.LIBRARY));
	}

	private void filter(String searchTerm, boolean refresh, boolean search) {
		this.method_25339();
		addedMods.clear();
		Collection<Mod> mods = ModMenu.MODS.values().stream().filter(mod -> {
			if (ModMenuConfig.CONFIG_MODE.getValue()) {
				Map<String, Boolean> modHasConfigScreen = parent.getModHasConfigScreen();
				var hasConfig = modHasConfigScreen.get(mod.getId());
				if (!hasConfig) {
					return false;
				}
			}

			return !mod.isHidden();
		}).collect(Collectors.toSet());

		if (DEBUG) {
			mods = new ArrayList<>(mods);
			//			mods.addAll(TestModContainer.getTestModContainers());
		}

		if (this.mods == null || refresh) {
			this.mods = new ArrayList<>();
			this.mods.addAll(mods);
			this.mods.sort(ModMenuConfig.SORTING.getValue().getComparator());
		}

		List<Mod> matched = ModSearch.search(parent, searchTerm, this.mods);

		for (Mod mod : matched) {
			String modId = mod.getId();

			//Hide parent lib mods when the config is set to hide
			if (mod.getBadges().contains(Mod.Badge.LIBRARY) && !ModMenuConfig.SHOW_LIBRARIES.getValue()) {
				continue;
			}

			if (!ModMenu.PARENT_MAP.values().contains(mod)) {
				if (ModMenu.PARENT_MAP.keySet().contains(mod) && hasVisibleChildMods(mod)) {
					//Add parent mods when not searching
					List<Mod> children = ModMenu.PARENT_MAP.get(mod);
					children.sort(ModMenuConfig.SORTING.getValue().getComparator());
					ParentEntry parent = new ParentEntry(mod, children, this);
					this.addEntry(parent);
					//Add children if they are meant to be shown
					if (this.parent.showModChildren.contains(modId)) {
						List<Mod> validChildren = ModSearch.search(this.parent, searchTerm, children);
						for (Mod child : validChildren) {
							this.addEntry(new ChildEntry(child,
								parent,
								this,
								validChildren.indexOf(child) == validChildren.size() - 1
							));
						}
					}
				} else {
					//A mod with no children
					this.addEntry(new IndependentEntry(mod, this));
				}
			}
		}

		if (parent.getSelectedEntry() != null && !method_25396().isEmpty() || this.method_25334() != null && method_25334().getMod() != parent.getSelectedEntry()
			.getMod()) {
			for (ModListEntry entry : method_25396()) {
				if (entry.getMod().equals(parent.getSelectedEntry().getMod())) {
					setSelected(entry);
				}
			}
		} else {
			if (method_25334() == null && !method_25396().isEmpty() && method_25326(0) != null) {
				setSelected(method_25326(0));
			}
		}

		if (method_25341() > Math.max(0, this.method_25317() - (this.method_55443() - this.method_46427() - 4))) {
			method_25307(Math.max(0, this.method_25317() - (this.method_55443() - this.method_46427() - 4)));
		}
	}


	@Override
	protected void method_25311(class_332 DrawContext, int mouseX, int mouseY, float delta) {
		int entryCount = this.method_25340();
		class_289 tessellator = class_289.method_1348();
		class_287 buffer;

		for (int index = 0; index < entryCount; ++index) {
			int entryTop = this.method_25337(index) + 2;
			int entryBottom = this.method_25337(index) + this.field_22741;
			if (entryBottom >= this.method_46427() && entryTop <= this.method_55443()) {
				int entryHeight = this.field_22741 - 4;
				ModListEntry entry = this.method_25326(index);
				int rowWidth = this.method_25322();
				int entryLeft;
				if (this.method_25332(index)) {
					entryLeft = method_25342() - 2 + entry.getXOffset();
					int selectionRight = this.method_25342() + rowWidth + 2;
					float float_2 = this.method_25370() ? 1.0F : 0.5F;
					RenderSystem.setShader(class_757::getPositionProgram);
					RenderSystem.setShaderColor(float_2, float_2, float_2, 1.0F);
					Matrix4f matrix = DrawContext.method_51448().method_23760().method_23761();
					class_9801 builtBuffer;
					buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
					buffer.method_22918(matrix, entryLeft, entryTop + entryHeight + 2, 0.0F);
					buffer.method_22918(matrix, selectionRight, entryTop + entryHeight + 2, 0.0F);
					buffer.method_22918(matrix, selectionRight, entryTop - 2, 0.0F);
					buffer.method_22918(matrix, entryLeft, entryTop - 2, 0.0F);
					try {
						builtBuffer = buffer.method_60800();
						class_286.method_43433(builtBuffer);
						builtBuffer.close();
					} catch (Exception e) {
						// Ignored
					}
					RenderSystem.setShader(class_757::getPositionProgram);
					RenderSystem.setShaderColor(0.0F, 0.0F, 0.0F, 1.0F);
					buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
					buffer.method_22918(matrix, entryLeft + 1, entryTop + entryHeight + 1, 0.0F);
					buffer.method_22918(matrix, selectionRight - 1, entryTop + entryHeight + 1, 0.0F);
					buffer.method_22918(matrix, selectionRight - 1, entryTop - 1, 0.0F);
					buffer.method_22918(matrix, entryLeft + 1, entryTop - 1, 0.0F);
					try {
						builtBuffer = buffer.method_60800();
						class_286.method_43433(builtBuffer);
						builtBuffer.close();
					} catch (Exception e) {
						// Ignored
					}
				}

				entryLeft = this.method_25342();
				entry.method_25343(DrawContext,
					index,
					entryTop,
					entryLeft,
					rowWidth,
					entryHeight,
					mouseX,
					mouseY,
					this.method_25405(mouseX, mouseY) && Objects.equals(this.getEntryAtPos(mouseX, mouseY), entry),
					delta
				);
			}
		}
	}

	public void ensureVisible(ModListEntry entry) {
		super.method_25328(entry);
	}

	@Override
	protected void method_25318(double double_1, double double_2, int int_1) {
		super.method_25318(double_1, double_2, int_1);
		this.scrolling = int_1 == 0 && double_1 >= (double) this.method_25329() && double_1 < (double) (this.method_25329() + 6);
	}

	@Override
	public boolean method_25402(double double_1, double double_2, int int_1) {
		this.method_25318(double_1, double_2, int_1);
		if (!this.method_25405(double_1, double_2)) {
			return false;
		} else {
			ModListEntry entry = this.getEntryAtPos(double_1, double_2);
			if (entry != null) {
				if (entry.method_25402(double_1, double_2, int_1)) {
					this.method_25395(entry);
					this.method_25398(true);
					return true;
				}
			} else if (int_1 == 0 && this.method_25310((int) (double_1 - (double) (this.method_46426() + this.field_22758 / 2 - this.method_25322() / 2)),
				(int) (double_2 - (double) this.method_46427()) + (int) this.method_25341() - 4
			)) {
				return true;
			}

			return this.scrolling;
		}
	}

	public boolean method_25404(int keyCode, int scanCode, int modifiers) {
		if (keyCode == GLFW.GLFW_KEY_UP || keyCode == GLFW.GLFW_KEY_DOWN) {
			return super.method_25404(keyCode, scanCode, modifiers);
		}
		if (method_25334() != null) {
			return method_25334().method_25404(keyCode, scanCode, modifiers);
		}
		return false;
	}

	public final ModListEntry getEntryAtPos(double x, double y) {
		int int_5 = class_3532.method_15357(y - (double) this.method_46427()) - this.field_22748 + (int) this.method_25341() - 4;
		int index = int_5 / this.field_22741;
		return x < (double) this.method_25329() && x >= (double) method_25342() && x <= (double) (method_25342() + method_25322()) && index >= 0 && int_5 >= 0 && index < this.method_25340() ?
			this.method_25396().get(index) :
			null;
	}

	@Override
	protected int method_25329() {
		return this.field_22758 - 6;
	}

	@Override
	public int method_25322() {
		return this.field_22758 - (Math.max(0, this.method_25317() - (this.method_55443() - this.method_46427() - 4)) > 0 ? 18 : 12);
	}

	@Override
	public int method_25342() {
		return this.method_46426() + 6;
	}

	public int method_25368() {
		return field_22758;
	}

	public int getTop() {
		return this.method_46427();
	}

	public ModsScreen getParent() {
		return parent;
	}

	@Override
	protected int method_25317() {
		return super.method_25317() + 4;
	}

	public int getDisplayedCountFor(Set<String> set) {
		int count = 0;
		for (ModListEntry c : method_25396()) {
			if (set.contains(c.getMod().getId())) {
				count++;
			}
		}
		return count;
	}

	@Override
	public void close() {
		iconHandler.close();
	}

	public FabricIconHandler getFabricIconHandler() {
		return iconHandler;
	}
}
