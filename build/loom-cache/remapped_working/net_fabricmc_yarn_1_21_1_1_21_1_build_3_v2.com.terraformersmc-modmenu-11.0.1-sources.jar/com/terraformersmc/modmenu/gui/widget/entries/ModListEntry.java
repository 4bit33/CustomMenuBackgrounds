package com.terraformersmc.modmenu.gui.widget.entries;

import I;
import com.mojang.blaze3d.systems.RenderSystem;
import com.terraformersmc.modmenu.ModMenu;
import com.terraformersmc.modmenu.config.ModMenuConfig;
import com.terraformersmc.modmenu.gui.widget.ModListWidget;
import com.terraformersmc.modmenu.gui.widget.UpdateAvailableBadge;
import com.terraformersmc.modmenu.util.DrawingUtil;
import com.terraformersmc.modmenu.util.ModMenuScreenTexts;
import com.terraformersmc.modmenu.util.mod.Mod;
import com.terraformersmc.modmenu.util.mod.ModBadgeRenderer;
import net.minecraft.class_1043;
import net.minecraft.class_156;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4280;
import net.minecraft.class_5348;

public class ModListEntry extends class_4280.class_4281<ModListEntry> {
	public static final class_2960 UNKNOWN_ICON = class_2960.method_60656("textures/misc/unknown_pack.png");
	private static final class_2960 MOD_CONFIGURATION_ICON = class_2960.method_60655(ModMenu.MOD_ID,
		"textures/gui/mod_configuration.png"
	);
	private static final class_2960 ERROR_ICON = class_2960.method_60656("world_list/error");
	private static final class_2960 ERROR_HIGHLIGHTED_ICON = class_2960.method_60656("world_list/error_highlighted");

	protected final class_310 client;
	public final Mod mod;
	protected final ModListWidget list;
	protected class_2960 iconLocation;
	protected static final int FULL_ICON_SIZE = 32;
	protected static final int COMPACT_ICON_SIZE = 19;
	protected long sinceLastClick;

	public ModListEntry(Mod mod, ModListWidget list) {
		this.mod = mod;
		this.list = list;
		this.client = class_310.method_1551();
	}

	@Override
	public class_2561 method_37006() {
		return class_2561.method_43470(mod.getTranslatedName());
	}

	@Override
	public void method_25343(
		class_332 DrawContext,
		int index,
		int y,
		int x,
		int rowWidth,
		int rowHeight,
		int mouseX,
		int mouseY,
		boolean hovered,
		float delta
	) {
		x += getXOffset();
		rowWidth -= getXOffset();
		int iconSize = ModMenuConfig.COMPACT_LIST.getValue() ? COMPACT_ICON_SIZE : FULL_ICON_SIZE;
		String modId = mod.getId();
		if ("java".equals(modId)) {
			DrawingUtil.drawRandomVersionBackground(mod, DrawContext, x, y, iconSize, iconSize);
		}
		RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
		RenderSystem.enableBlend();
		DrawContext.method_25290(this.getIconTexture(), x, y, 0.0F, 0.0F, iconSize, iconSize, iconSize, iconSize);
		RenderSystem.disableBlend();
		class_2561 name = class_2561.method_43470(mod.getTranslatedName());
		class_5348 trimmedName = name;
		int maxNameWidth = rowWidth - iconSize - 3;
		class_327 font = this.client.field_1772;
		if (font.method_27525(name) > maxNameWidth) {
			class_5348 ellipsis = class_5348.method_29430("...");
			trimmedName = class_5348.method_29433(font.method_1714(name, maxNameWidth - font.method_27525(ellipsis)),
				ellipsis
			);
		}
		DrawContext.method_51430(font,
			class_2477.method_10517().method_30934(trimmedName),
			x + iconSize + 3,
			y + 1,
			0xFFFFFF,
			true
		);
		var updateBadgeXOffset = 0;
		if (ModMenuConfig.UPDATE_CHECKER.getValue() && !ModMenuConfig.DISABLE_UPDATE_CHECKER.getValue()
			.contains(modId) && (mod.hasUpdate() || mod.getChildHasUpdate())) {
			UpdateAvailableBadge.renderBadge(DrawContext, x + iconSize + 3 + font.method_27525(name) + 2, y);
			updateBadgeXOffset = 11;
		}
		if (!ModMenuConfig.HIDE_BADGES.getValue()) {
			new ModBadgeRenderer(x + iconSize + 3 + font.method_27525(name) + 2 + updateBadgeXOffset,
				y,
				x + rowWidth,
				mod,
				list.getParent()
			).draw(DrawContext, mouseX, mouseY);
		}
		if (!ModMenuConfig.COMPACT_LIST.getValue()) {
			String summary = mod.getSummary();
			DrawingUtil.drawWrappedString(DrawContext,
				summary,
				(x + iconSize + 3 + 4),
				(y + client.field_1772.field_2000 + 2),
				rowWidth - iconSize - 7,
				2,
				0x808080
			);
		} else {
			DrawingUtil.drawWrappedString(DrawContext,
				mod.getPrefixedVersion(),
				(x + iconSize + 3),
				(y + client.field_1772.field_2000 + 2),
				rowWidth - iconSize - 7,
				2,
				0x808080
			);
		}

		if (!(this instanceof ParentEntry) && ModMenuConfig.QUICK_CONFIGURE.getValue() && (this.list.getParent()
			.getModHasConfigScreen()
			.get(modId) || this.list.getParent().modScreenErrors.containsKey(modId))) {
			final int textureSize = ModMenuConfig.COMPACT_LIST.getValue() ?
				(int) (256 / (FULL_ICON_SIZE / (double) COMPACT_ICON_SIZE)) :
				256;
			if (this.client.field_1690.method_42446().method_41753() || hovered) {
				DrawContext.method_25294(x, y, x + iconSize, y + iconSize, -1601138544);
				boolean hoveringIcon = mouseX - x < iconSize;
				if (this.list.getParent().modScreenErrors.containsKey(modId)) {
					DrawContext.method_52706(hoveringIcon ? ERROR_HIGHLIGHTED_ICON : ERROR_ICON,
						x,
						y,
						iconSize,
						iconSize
					);
					if (hoveringIcon) {
						Throwable e = this.list.getParent().modScreenErrors.get(modId);
						this.list.getParent()
							.method_47414(this.client.field_1772.method_1728(
								ModMenuScreenTexts.configureError(modId, e),
								175
							));
					}
				} else {
					int v = hoveringIcon ? iconSize : 0;
					DrawContext.method_25290(MOD_CONFIGURATION_ICON,
						x,
						y,
						0.0F,
						(float) v,
						iconSize,
						iconSize,
						textureSize,
						textureSize
					);
				}
			}
		}
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int delta) {
		list.select(this);
		if (ModMenuConfig.QUICK_CONFIGURE.getValue() && this.list.getParent()
			.getModHasConfigScreen()
			.get(this.mod.getId())) {
			int iconSize = ModMenuConfig.COMPACT_LIST.getValue() ? COMPACT_ICON_SIZE : FULL_ICON_SIZE;
			if (mouseX - list.method_25342() <= iconSize) {
				this.openConfig();
			} else if (class_156.method_658() - this.sinceLastClick < 250) {
				this.openConfig();
			}
		}
		this.sinceLastClick = class_156.method_658();
		return true;
	}

	public void openConfig() {
		class_310.method_1551().method_1507(ModMenu.getConfigScreen(mod.getId(), list.getParent()));
	}

	public Mod getMod() {
		return mod;
	}

	public class_2960 getIconTexture() {
		if (this.iconLocation == null) {
			this.iconLocation = class_2960.method_60655(ModMenu.MOD_ID, mod.getId() + "_icon");
			class_1043 icon = mod.getIcon(list.getFabricIconHandler(),
				64 * this.client.field_1690.method_42474().method_41753()
			);
			if (icon != null) {
				this.client.method_1531().method_4616(this.iconLocation, icon);
			} else {
				this.iconLocation = UNKNOWN_ICON;
			}
		}
		return iconLocation;
	}

	public int getXOffset() {
		return 0;
	}
}
