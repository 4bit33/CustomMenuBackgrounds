package com.terraformersmc.modmenu.gui.widget;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public class UpdateAvailableBadge {
	private static final class_2960 UPDATE_ICON = class_2960.method_60656("icon/trial_available");

	public static void renderBadge(class_332 DrawContext, int x, int y) {
		RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
		int animOffset = 0;
		if ((class_156.method_658() / 800L & 1L) == 1L) {
			animOffset = 8;
		}
		DrawContext.method_52706(UPDATE_ICON, x, y, 8, 8);
	}
}
