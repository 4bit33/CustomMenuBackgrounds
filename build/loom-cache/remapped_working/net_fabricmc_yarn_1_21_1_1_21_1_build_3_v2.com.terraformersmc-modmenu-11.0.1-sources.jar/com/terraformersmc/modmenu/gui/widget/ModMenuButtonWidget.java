package com.terraformersmc.modmenu.gui.widget;

import com.terraformersmc.modmenu.ModMenu;
import com.terraformersmc.modmenu.config.ModMenuConfig;
import com.terraformersmc.modmenu.gui.ModsScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ModMenuButtonWidget extends class_4185 {
	public ModMenuButtonWidget(int x, int y, int width, int height, class_2561 text, class_437 screen) {
		super(x,
			y,
			width,
			height,
			text,
			button -> class_310.method_1551().method_1507(new ModsScreen(screen)),
			class_4185.field_40754
		);
	}

	@Override
	public void method_48579(class_332 DrawContext, int mouseX, int mouseY, float delta) {
		super.method_48579(DrawContext, mouseX, mouseY, delta);
		if (ModMenuConfig.BUTTON_UPDATE_BADGE.getValue() && ModMenu.areModUpdatesAvailable()) {
			UpdateAvailableBadge.renderBadge(DrawContext,
				this.field_22758 + this.method_46426() - 16,
				this.field_22759 / 2 + this.method_46427() - 4
			);
		}
	}
}
