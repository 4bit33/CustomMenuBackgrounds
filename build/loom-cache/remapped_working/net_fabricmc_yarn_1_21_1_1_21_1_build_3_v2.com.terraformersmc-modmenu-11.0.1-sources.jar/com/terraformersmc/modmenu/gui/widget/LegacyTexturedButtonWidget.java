package com.terraformersmc.modmenu.gui.widget;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_4185;

public class LegacyTexturedButtonWidget extends class_344 {
	private final int u;
	private final int v;
	private final int hoveredVOffset;

	private final class_2960 texture;

	private final int textureWidth;
	private final int textureHeight;

	public LegacyTexturedButtonWidget(
		int x,
		int y,
		int width,
		int height,
		int u,
		int v,
		int hoveredVOffset,
		class_2960 texture,
		int textureWidth,
		int textureHeight,
		class_4185.class_4241 pressAction,
		class_2561 message
	) {
		super(x, y, width, height, null, pressAction, message);

		this.u = u;
		this.v = v;
		this.hoveredVOffset = hoveredVOffset;

		this.texture = texture;

		this.textureWidth = textureWidth;
		this.textureHeight = textureHeight;
	}

	@Override
	public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
		int v = this.v;

		if (!this.method_37303()) {
			v += this.hoveredVOffset * 2;
		} else if (this.method_25367()) {
			v += this.hoveredVOffset;
		}

		context.method_25290(this.texture,
			this.method_46426(),
			this.method_46427(),
			this.u,
			v,
			this.field_22758,
			this.field_22759,
			this.textureWidth,
			this.textureHeight
		);
	}

	public static Builder legacyTexturedBuilder(class_2561 message, class_4185.class_4241 onPress) {
		return new Builder(message, onPress);
	}

	public static class Builder {
		private final class_2561 message;
		private final class_4185.class_4241 onPress;

		private int x;
		private int y;

		private int width;
		private int height;

		private int u;
		private int v;
		private int hoveredVOffset;

		private class_2960 texture;

		private int textureWidth;
		private int textureHeight;

		public Builder(class_2561 message, class_4241 onPress) {
			this.message = message;
			this.onPress = onPress;
		}

		public Builder position(int x, int y) {
			this.x = x;
			this.y = y;

			return this;
		}

		public Builder size(int width, int height) {
			this.width = width;
			this.height = height;

			return this;
		}

		public Builder uv(int u, int v, int hoveredVOffset) {
			this.u = u;
			this.v = v;

			this.hoveredVOffset = hoveredVOffset;

			return this;
		}

		public Builder texture(class_2960 texture, int textureWidth, int textureHeight) {
			this.texture = texture;

			this.textureWidth = textureWidth;
			this.textureHeight = textureHeight;

			return this;
		}

		public LegacyTexturedButtonWidget build() {
			return new LegacyTexturedButtonWidget(this.x,
				this.y,
				this.width,
				this.height,
				this.u,
				this.v,
				this.hoveredVOffset,
				this.texture,
				this.textureWidth,
				this.textureHeight,
				this.onPress,
				this.message
			);
		}
	}
}
