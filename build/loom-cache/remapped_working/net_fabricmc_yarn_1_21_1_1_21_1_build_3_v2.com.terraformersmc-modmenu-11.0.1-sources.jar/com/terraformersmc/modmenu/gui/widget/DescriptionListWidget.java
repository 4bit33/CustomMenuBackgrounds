package com.terraformersmc.modmenu.gui.widget;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.terraformersmc.modmenu.api.UpdateInfo;
import com.terraformersmc.modmenu.config.ModMenuConfig;
import com.terraformersmc.modmenu.gui.ModsScreen;
import com.terraformersmc.modmenu.gui.widget.entries.ModListEntry;
import com.terraformersmc.modmenu.util.mod.Mod;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_407;
import net.minecraft.class_4265;
import net.minecraft.class_5481;
import net.minecraft.class_6379;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_757;
import net.minecraft.class_8219;
import net.minecraft.class_9801;
import net.minecraft.client.render.*;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;

public class DescriptionListWidget extends class_350<DescriptionListWidget.DescriptionEntry> {

	private static final class_2561 HAS_UPDATE_TEXT = class_2561.method_43471("modmenu.hasUpdate");
	private static final class_2561 EXPERIMENTAL_TEXT = class_2561.method_43471("modmenu.experimental").method_27692(class_124.field_1065);
	private static final class_2561 DOWNLOAD_TEXT = class_2561.method_43471("modmenu.downloadLink")
		.method_27692(class_124.field_1078)
		.method_27692(class_124.field_1073);
	private static final class_2561 CHILD_HAS_UPDATE_TEXT = class_2561.method_43471("modmenu.childHasUpdate");
	private static final class_2561 LINKS_TEXT = class_2561.method_43471("modmenu.links");
	private static final class_2561 SOURCE_TEXT = class_2561.method_43471("modmenu.source")
		.method_27692(class_124.field_1078)
		.method_27692(class_124.field_1073);
	private static final class_2561 LICENSE_TEXT = class_2561.method_43471("modmenu.license");
	private static final class_2561 VIEW_CREDITS_TEXT = class_2561.method_43471("modmenu.viewCredits")
		.method_27692(class_124.field_1078)
		.method_27692(class_124.field_1073);
	private static final class_2561 CREDITS_TEXT = class_2561.method_43471("modmenu.credits");

	private final ModsScreen parent;
	private final class_327 textRenderer;
	private ModListEntry lastSelected = null;

	public DescriptionListWidget(
		class_310 client,
		int width,
		int height,
		int y,
		int itemHeight,
		ModsScreen parent
	) {
		super(client, width, height, y, itemHeight);
		this.parent = parent;
		this.textRenderer = client.field_1772;
	}

	@Override
	public DescriptionEntry method_25334() {
		return null;
	}

	@Override
	public int method_25322() {
		return this.field_22758 - 10;
	}

	@Override
	protected int method_25329() {
		return this.field_22758 - 6 + this.method_46426();
	}

	@Override
	public void method_47399(class_6382 builder) {
		Mod mod = parent.getSelectedEntry().getMod();
		builder.method_37033(class_6381.field_33788, mod.getTranslatedName() + " " + mod.getPrefixedVersion());
	}

	@Override
	public void method_25311(class_332 DrawContext, int mouseX, int mouseY, float delta) {
		ModListEntry selectedEntry = parent.getSelectedEntry();
		if (selectedEntry != lastSelected) {
			lastSelected = selectedEntry;
			method_25339();
			method_25307(-Double.MAX_VALUE);
			if (lastSelected != null) {
				DescriptionEntry emptyEntry = new DescriptionEntry(class_5481.field_26385);
				int wrapWidth = method_25322() - 5;

				Mod mod = lastSelected.getMod();
				class_2561 description = mod.getFormattedDescription();
				if (!description.getString().isEmpty()) {
					for (class_5481 line : textRenderer.method_1728(description, wrapWidth)) {
						method_25396().add(new DescriptionEntry(line));
					}
				}

				if (ModMenuConfig.UPDATE_CHECKER.getValue() && !ModMenuConfig.DISABLE_UPDATE_CHECKER.getValue()
					.contains(mod.getId())) {
					UpdateInfo updateInfo = mod.getUpdateInfo();
					if (updateInfo != null && updateInfo.isUpdateAvailable()) {
						method_25396().add(emptyEntry);

						int index = 0;
						for (class_5481 line : textRenderer.method_1728(HAS_UPDATE_TEXT, wrapWidth - 11)) {
							DescriptionEntry entry = new DescriptionEntry(line);
							if (index == 0) {
								entry.setUpdateTextEntry();
							}

							method_25396().add(entry);
							index += 1;
						}

						for (class_5481 line : textRenderer.method_1728(EXPERIMENTAL_TEXT, wrapWidth - 16)) {
							method_25396().add(new DescriptionEntry(line, 8));
						}


						class_2561 updateMessage = updateInfo.getUpdateMessage();
						String downloadLink = updateInfo.getDownloadLink();
						if (updateMessage == null) {
							updateMessage = DOWNLOAD_TEXT;
						} else {
							if (downloadLink != null) {
								updateMessage = updateMessage.method_27661()
									.method_27692(class_124.field_1078)
									.method_27692(class_124.field_1073);
							}
						}
						for (class_5481 line : textRenderer.method_1728(updateMessage, wrapWidth - 16)) {
							if (downloadLink != null) {
								method_25396().add(new LinkEntry(line, downloadLink, 8));
							} else {
								method_25396().add(new DescriptionEntry(line, 8));

							}
						}
					}
					if (mod.getChildHasUpdate()) {
						method_25396().add(emptyEntry);

						int index = 0;
						for (class_5481 line : textRenderer.method_1728(CHILD_HAS_UPDATE_TEXT, wrapWidth - 11)) {
							DescriptionEntry entry = new DescriptionEntry(line);
							if (index == 0) {
								entry.setUpdateTextEntry();
							}

							method_25396().add(entry);
							index += 1;
						}
					}
				}

				Map<String, String> links = mod.getLinks();
				String sourceLink = mod.getSource();
				if ((!links.isEmpty() || sourceLink != null) && !ModMenuConfig.HIDE_MOD_LINKS.getValue()) {
					method_25396().add(emptyEntry);

					for (class_5481 line : textRenderer.method_1728(LINKS_TEXT, wrapWidth)) {
						method_25396().add(new DescriptionEntry(line));
					}

					if (sourceLink != null) {
						int indent = 8;
						for (class_5481 line : textRenderer.method_1728(SOURCE_TEXT, wrapWidth - 16)) {
							method_25396().add(new LinkEntry(line, sourceLink, indent));
							indent = 16;
						}
					}

					links.forEach((key, value) -> {
						int indent = 8;
						for (class_5481 line : textRenderer.method_1728(class_2561.method_43471(key)
								.method_27692(class_124.field_1078)
								.method_27692(class_124.field_1073),
							wrapWidth - 16
						)) {
							method_25396().add(new LinkEntry(line, value, indent));
							indent = 16;
						}
					});
				}

				Set<String> licenses = mod.getLicense();
				if (!ModMenuConfig.HIDE_MOD_LICENSE.getValue() && !licenses.isEmpty()) {
					method_25396().add(emptyEntry);

					for (class_5481 line : textRenderer.method_1728(LICENSE_TEXT, wrapWidth)) {
						method_25396().add(new DescriptionEntry(line));
					}

					for (String license : licenses) {
						int indent = 8;
						for (class_5481 line : textRenderer.method_1728(class_2561.method_43470(license), wrapWidth - 16)) {
							method_25396().add(new DescriptionEntry(line, indent));
							indent = 16;
						}
					}
				}

				if (!ModMenuConfig.HIDE_MOD_CREDITS.getValue()) {
					if ("minecraft".equals(mod.getId())) {
						method_25396().add(emptyEntry);

						for (class_5481 line : textRenderer.method_1728(VIEW_CREDITS_TEXT, wrapWidth)) {
							method_25396().add(new MojangCreditsEntry(line));
						}
					} else if (!"java".equals(mod.getId())) {
						var credits = mod.getCredits();

						if (!credits.isEmpty()) {
							method_25396().add(emptyEntry);

							for (class_5481 line : textRenderer.method_1728(CREDITS_TEXT, wrapWidth)) {
								method_25396().add(new DescriptionEntry(line));
							}

							var iterator = credits.entrySet().iterator();

							while (iterator.hasNext()) {
								int indent = 8;

								var role = iterator.next();
								var roleName = role.getKey();

								for (var line : textRenderer.method_1728(this.creditsRoleText(roleName),
									wrapWidth - 16
								)) {
									method_25396().add(new DescriptionEntry(line, indent));
									indent = 16;
								}

								for (var contributor : role.getValue()) {
									indent = 16;

									for (var line : textRenderer.method_1728(class_2561.method_43470(contributor), wrapWidth - 24)) {
										method_25396().add(new DescriptionEntry(line, indent));
										indent = 24;
									}
								}

								if (iterator.hasNext()) {
									method_25396().add(emptyEntry);
								}
							}
						}
					}
				}
			}
		}

		class_289 tessellator = class_289.method_1348();
		class_287 bufferBuilder;
		class_9801 builtBuffer;

		//		{
		//			RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
		//			RenderSystem.setShaderTexture(0, Screen.OPTIONS_BACKGROUND_TEXTURE);
		//			RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
		//			bufferBuilder.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
		//			bufferBuilder.vertex(this.getX(), this.getBottom(), 0.0D).texture(this.getX() / 32.0F, (this.getBottom() + (int) this.getScrollAmount()) / 32.0F).color(32, 32, 32, 255);
		//			bufferBuilder.vertex(this.getRight(), this.getBottom(), 0.0D).texture(this.getRight() / 32.0F, (this.getBottom() + (int) this.getScrollAmount()) / 32.0F).color(32, 32, 32, 255);
		//			bufferBuilder.vertex(this.getRight(), this.getY(), 0.0D).texture(this.getRight() / 32.0F, (this.getY() + (int) this.getScrollAmount()) / 32.0F).color(32, 32, 32, 255);
		//			bufferBuilder.vertex(this.getX(), this.getY(), 0.0D).texture(this.getX() / 32.0F, (this.getY() + (int) this.getScrollAmount()) / 32.0F).color(32, 32, 32, 255);
		//			tessellator.draw();
		//		}

		this.method_49603(DrawContext);
		super.method_25311(DrawContext, mouseX, mouseY, delta);
		DrawContext.method_44380();

		RenderSystem.depthFunc(515);
		RenderSystem.disableDepthTest();
		RenderSystem.enableBlend();
		RenderSystem.blendFuncSeparate(GlStateManager.SrcFactor.SRC_ALPHA,
			GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA,
			GlStateManager.SrcFactor.ZERO,
			GlStateManager.DstFactor.ONE
		);
		RenderSystem.setShader(class_757::getPositionColorProgram);

		bufferBuilder = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1576);
		bufferBuilder.method_22912(this.method_46426(), (this.method_46427() + 4), 0.0F).

			method_1336(0, 0, 0, 0);

		bufferBuilder.method_22912(this.method_55442(), (this.method_46427() + 4), 0.0F).

			method_1336(0, 0, 0, 0);

		bufferBuilder.method_22912(this.method_55442(), this.method_46427(), 0.0F).

			method_1336(0, 0, 0, 255);

		bufferBuilder.method_22912(this.method_46426(), this.method_46427(), 0.0F).

			method_1336(0, 0, 0, 255);

		bufferBuilder.method_22912(this.method_46426(), this.method_55443(), 0.0F).

			method_1336(0, 0, 0, 255);

		bufferBuilder.method_22912(this.method_55442(), this.method_55443(), 0.0F).

			method_1336(0, 0, 0, 255);

		bufferBuilder.method_22912(this.method_55442(), (this.method_55443() - 4), 0.0F).

			method_1336(0, 0, 0, 0);

		bufferBuilder.method_22912(this.method_46426(), (this.method_55443() - 4), 0.0F).

			method_1336(0, 0, 0, 0);

		try {
			builtBuffer = bufferBuilder.method_60800();
			class_286.method_43433(builtBuffer);
			builtBuffer.close();
		} catch (Exception e) {
			// Ignored
		}
		this.renderScrollBar(bufferBuilder, tessellator);

		RenderSystem.disableBlend();
	}

	public void renderScrollBar(class_287 bufferBuilder, class_289 tessellator) {
		class_9801 builtBuffer;
		int scrollbarStartX = this.method_25329();
		int scrollbarEndX = scrollbarStartX + 6;
		int maxScroll = this.method_25331();
		if (maxScroll > 0) {
			int p = (int) ((float) ((this.method_55443() - this.method_46427()) * (this.method_55443() - this.method_46427())) / (float) this.method_25317());
			p = class_3532.method_15340(p, 32, this.method_55443() - this.method_46427() - 8);
			int q = (int) this.method_25341() * (this.method_55443() - this.method_46427() - p) / maxScroll + this.method_46427();
			if (q < this.method_46427()) {
				q = this.method_46427();
			}

			RenderSystem.setShader(class_757::getPositionColorProgram);
			bufferBuilder = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1576);
			bufferBuilder.method_22912(scrollbarStartX, this.method_55443(), 0.0F).method_1336(0, 0, 0, 255);
			bufferBuilder.method_22912(scrollbarEndX, this.method_55443(), 0.0F).method_1336(0, 0, 0, 255);
			bufferBuilder.method_22912(scrollbarEndX, this.method_46427(), 0.0F).method_1336(0, 0, 0, 255);
			bufferBuilder.method_22912(scrollbarStartX, this.method_46427(), 0.0F).method_1336(0, 0, 0, 255);
			bufferBuilder.method_22912(scrollbarStartX, q + p, 0.0F).method_1336(128, 128, 128, 255);
			bufferBuilder.method_22912(scrollbarEndX, q + p, 0.0F).method_1336(128, 128, 128, 255);
			bufferBuilder.method_22912(scrollbarEndX, q, 0.0F).method_1336(128, 128, 128, 255);
			bufferBuilder.method_22912(scrollbarStartX, q, 0.0F).method_1336(128, 128, 128, 255);
			bufferBuilder.method_22912(scrollbarStartX, q + p - 1, 0.0F).method_1336(192, 192, 192, 255);
			bufferBuilder.method_22912(scrollbarEndX - 1, q + p - 1, 0.0F).method_1336(192, 192, 192, 255);
			bufferBuilder.method_22912(scrollbarEndX - 1, q, 0.0F).method_1336(192, 192, 192, 255);
			bufferBuilder.method_22912(scrollbarStartX, q, 0.0F).method_1336(192, 192, 192, 255);
			try {
				builtBuffer = bufferBuilder.method_60800();
				class_286.method_43433(builtBuffer);
				builtBuffer.close();
			} catch (Exception e) {
				// Ignored
			}
		}
	}

	private class_2561 creditsRoleText(String roleName) {
		// Replace spaces and dashes in role names with underscores if they exist
		// Notably Quilted Fabric API does this with FabricMC as "Upstream Owner"
		var translationKey = roleName.replaceAll("[ -]", "_").toLowerCase();

		// Add an s to the default untranslated string if it ends in r since this
		// Fixes common role names people use in English (e.g. Author -> Authors)
		var fallback = roleName.endsWith("r") ? roleName + "s" : roleName;

		return class_2561.method_48321("modmenu.credits.role." + translationKey, fallback)
			.method_10852(class_2561.method_43470(":"));
	}

	protected class DescriptionEntry extends class_4265.class_4266<DescriptionEntry> {
		protected class_5481 text;
		protected int indent;
		public boolean updateTextEntry = false;

		public DescriptionEntry(class_5481 text, int indent) {
			this.text = text;
			this.indent = indent;
		}

		public DescriptionEntry(class_5481 text) {
			this(text, 0);
		}

		public DescriptionEntry setUpdateTextEntry() {
			this.updateTextEntry = true;
			return this;
		}

		@Override
		public void method_25343(
			class_332 DrawContext,
			int index,
			int y,
			int x,
			int itemWidth,
			int itemHeight,
			int mouseX,
			int mouseY,
			boolean isSelected,
			float delta
		) {
			if (updateTextEntry) {
				UpdateAvailableBadge.renderBadge(DrawContext, x + indent, y);
				x += 11;
			}
			DrawContext.method_35720(textRenderer, text, x + indent, y, 0xAAAAAA);
		}

		@Override
		public List<? extends class_364> method_25396() {
			return Collections.emptyList();
		}

		@Override
		public List<? extends class_6379> method_37025() {
			return Collections.emptyList();
		}
	}

	protected class MojangCreditsEntry extends DescriptionEntry {
		public MojangCreditsEntry(class_5481 text) {
			super(text);
		}

		@Override
		public boolean method_25402(double mouseX, double mouseY, int button) {
			if (method_25405(mouseX, mouseY)) {
				field_22740.method_1507(new MinecraftCredits());
			}
			return super.method_25402(mouseX, mouseY, button);
		}

		class MinecraftCredits extends class_8219 {
			public MinecraftCredits() {
				super(parent);
			}
		}
	}

	protected class LinkEntry extends DescriptionEntry {
		private final String link;

		public LinkEntry(class_5481 text, String link, int indent) {
			super(text, indent);
			this.link = link;
		}

		public LinkEntry(class_5481 text, String link) {
			this(text, link, 0);
		}

		@Override
		public boolean method_25402(double mouseX, double mouseY, int button) {
			if (method_25405(mouseX, mouseY)) {
				field_22740.method_1507(new class_407((open) -> {
					if (open) {
						class_156.method_668().method_670(link);
					}
					field_22740.method_1507(parent);
				}, link, false));
			}
			return super.method_25402(mouseX, mouseY, button);
		}
	}

}
