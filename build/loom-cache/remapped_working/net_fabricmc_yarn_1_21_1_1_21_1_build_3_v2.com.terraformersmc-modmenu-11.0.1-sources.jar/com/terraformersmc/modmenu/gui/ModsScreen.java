package com.terraformersmc.modmenu.gui;

import Z;
import com.google.common.base.Joiner;
import com.mojang.blaze3d.systems.RenderSystem;
import com.terraformersmc.modmenu.ModMenu;
import com.terraformersmc.modmenu.config.ModMenuConfig;
import com.terraformersmc.modmenu.config.ModMenuConfigManager;
import com.terraformersmc.modmenu.gui.widget.DescriptionListWidget;
import com.terraformersmc.modmenu.gui.widget.LegacyTexturedButtonWidget;
import com.terraformersmc.modmenu.gui.widget.ModListWidget;
import com.terraformersmc.modmenu.gui.widget.entries.ModListEntry;
import com.terraformersmc.modmenu.util.DrawingUtil;
import com.terraformersmc.modmenu.util.ModMenuScreenTexts;
import com.terraformersmc.modmenu.util.TranslationUtil;
import com.terraformersmc.modmenu.util.mod.Mod;
import com.terraformersmc.modmenu.util.mod.ModBadgeRenderer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_155;
import net.minecraft.class_156;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_370;
import net.minecraft.class_407;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5348;
import net.minecraft.class_7919;
import net.minecraft.class_8216;
import net.minecraft.util.*;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.jar.JarFile;
import java.util.stream.Collectors;

public class ModsScreen extends class_437 {
	private static final class_2960 FILTERS_BUTTON_LOCATION = class_2960.method_60655(ModMenu.MOD_ID,
		"textures/gui/filters_button.png"
	);
	private static final class_2960 CONFIGURE_BUTTON_LOCATION = class_2960.method_60655(ModMenu.MOD_ID,
		"textures/gui/configure_button.png"
	);

	private static final Logger LOGGER = LoggerFactory.getLogger("Mod Menu | ModsScreen");
	private final class_437 previousScreen;
	private ModListEntry selected;
	private ModBadgeRenderer modBadgeRenderer;
	private double scrollPercent = 0;
	private boolean keepFilterOptionsShown = false;
	private boolean init = false;
	private boolean filterOptionsShown = false;
	private static final int RIGHT_PANE_Y = 48;
	private int paneWidth;
	private int rightPaneX;
	private int searchBoxX;
	private int filtersX;
	private int filtersWidth;
	private int searchRowWidth;
	public final Set<String> showModChildren = new HashSet<>();

	private class_342 searchBox;
	private @Nullable class_339 filtersButton;
	private class_339 sortingButton;
	private class_339 librariesButton;
	private ModListWidget modList;
	private @Nullable class_339 configureButton;
	private class_339 websiteButton;
	private class_339 issuesButton;
	private DescriptionListWidget descriptionListWidget;
	private class_339 modsFolderButton;
	private class_339 doneButton;

	public final Map<String, Boolean> modHasConfigScreen = new HashMap<>();
	public final Map<String, Throwable> modScreenErrors = new HashMap<>();

	private static final class_2561 SEND_FEEDBACK_TEXT = class_2561.method_43471("menu.sendFeedback");
	private static final class_2561 REPORT_BUGS_TEXT = class_2561.method_43471("menu.reportBugs");

	public ModsScreen(class_437 previousScreen) {
		super(ModMenuScreenTexts.TITLE);
		this.previousScreen = previousScreen;
	}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		if (modList.method_25405(mouseX, mouseY)) {
			return this.modList.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
		}
		if (descriptionListWidget.method_25405(mouseX, mouseY)) {
			return this.descriptionListWidget.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
		}
		return false;
	}

	@Override
	protected void method_25426() {
		for (Mod mod : ModMenu.MODS.values()) {
			String id = mod.getId();
			if (!modHasConfigScreen.containsKey(id)) {
				try {
					class_437 configScreen = ModMenu.getConfigScreen(id, this);
					modHasConfigScreen.put(id, configScreen != null);
				} catch (java.lang.NoClassDefFoundError e) {
					LOGGER.warn(
						"The '" + id + "' mod config screen is not available because " + e.getLocalizedMessage() +
							" is missing.");
					modScreenErrors.put(id, e);
					modHasConfigScreen.put(id, false);
				} catch (Throwable e) {
					LOGGER.error("Error from mod '" + id + "'", e);
					modScreenErrors.put(id, e);
					modHasConfigScreen.put(id, false);
				}
			}
		}

		int paneY = ModMenuConfig.CONFIG_MODE.getValue() ? 48 : 48 + 19;
		this.paneWidth = this.field_22789 / 2 - 8;
		this.rightPaneX = this.field_22789 - this.paneWidth;

		// Mod list (initialized early for updateFiltersX)
		this.modList = new ModListWidget(this.field_22787,
			this.paneWidth,
			this.field_22790 - paneY - 36,
			paneY,
			ModMenuConfig.COMPACT_LIST.getValue() ? 23 : 36,
			this.modList,
			this
		);
		this.modList.method_46421(0);

		// Search box
		int filtersButtonSize = (ModMenuConfig.CONFIG_MODE.getValue() ? 0 : 22);
		int searchWidthMax = this.paneWidth - 32 - filtersButtonSize;
		int searchBoxWidth = ModMenuConfig.CONFIG_MODE.getValue() ? Math.min(200, searchWidthMax) : searchWidthMax;

		this.searchBoxX = this.paneWidth / 2 - searchBoxWidth / 2 - filtersButtonSize / 2;

		this.searchBox = new class_342(this.field_22793,
			this.searchBoxX,
			22,
			searchBoxWidth,
			20,
			this.searchBox,
			ModMenuScreenTexts.SEARCH
		);
		this.searchBox.method_1863(text -> {
			this.modList.filter(text, false);
		});

		// Filters button
		class_2561 sortingText = ModMenuConfig.SORTING.getButtonText();
		class_2561 librariesText = ModMenuConfig.SHOW_LIBRARIES.getButtonText();

		int sortingWidth = field_22793.method_27525(sortingText) + 20;
		int librariesWidth = field_22793.method_27525(librariesText) + 20;

		this.filtersWidth = librariesWidth + sortingWidth + 2;
		this.searchRowWidth = this.searchBoxX + searchBoxWidth + 22;

		this.updateFiltersX();

		if (!ModMenuConfig.CONFIG_MODE.getValue()) {
			this.filtersButton = LegacyTexturedButtonWidget.legacyTexturedBuilder(ModMenuScreenTexts.TOGGLE_FILTER_OPTIONS,
					button -> {
						this.setFilterOptionsShown(!this.filterOptionsShown);
					}
				)
				.position(this.paneWidth / 2 + searchBoxWidth / 2 - 20 / 2 + 2, 22)
				.size(20, 20)
				.uv(0, 0, 20)
				.texture(FILTERS_BUTTON_LOCATION, 32, 64)
				.build();

			this.filtersButton.method_47400(class_7919.method_47407(ModMenuScreenTexts.TOGGLE_FILTER_OPTIONS));
		}

		// Sorting button
		this.sortingButton = class_4185.method_46430(sortingText, button -> {
			ModMenuConfig.SORTING.cycleValue();
			ModMenuConfigManager.save();
			modList.reloadFilters();
			button.method_25355(ModMenuConfig.SORTING.getButtonText());
		}).method_46433(this.filtersX, 45).method_46437(sortingWidth, 20).method_46431();

		// Show libraries button
		this.librariesButton = class_4185.method_46430(librariesText, button -> {
			ModMenuConfig.SHOW_LIBRARIES.toggleValue();
			ModMenuConfigManager.save();
			modList.reloadFilters();
			button.method_25355(ModMenuConfig.SHOW_LIBRARIES.getButtonText());
		}).method_46433(this.filtersX + sortingWidth + 2, 45).method_46437(librariesWidth, 20).method_46431();

		// Configure button
		if (!ModMenuConfig.HIDE_CONFIG_BUTTONS.getValue()) {
			this.configureButton = LegacyTexturedButtonWidget.legacyTexturedBuilder(class_5244.field_39003, button -> {
					final String id = Objects.requireNonNull(selected).getMod().getId();
					if (modHasConfigScreen.get(id)) {
						class_437 configScreen = ModMenu.getConfigScreen(id, this);
						field_22787.method_1507(configScreen);
					} else {
						button.field_22763 = false;
					}
				})
				.position(field_22789 - 24, RIGHT_PANE_Y)
				.size(20, 20)
				.uv(0, 0, 20)
				.texture(CONFIGURE_BUTTON_LOCATION, 32, 64)
				.build();
		}

		// Website button
		int urlButtonWidths = this.paneWidth / 2 - 2;
		int cappedButtonWidth = Math.min(urlButtonWidths, 200);

		this.websiteButton = class_4185.method_46430(ModMenuScreenTexts.WEBSITE, button -> {
				final Mod mod = Objects.requireNonNull(selected).getMod();
				boolean isMinecraft = selected.getMod().getId().equals("minecraft");

				if (isMinecraft) {
					var url = class_155.method_16673().method_48022() ? class_8216.field_43124 : class_8216.field_43123;
					class_407.method_61034(this, url, true);
				} else {
					var url = mod.getWebsite();
					class_407.method_60866(this, url, false);
				}
			})
			.method_46433(this.rightPaneX + (urlButtonWidths / 2) - (cappedButtonWidth / 2), RIGHT_PANE_Y + 36)
			.method_46437(Math.min(urlButtonWidths, 200), 20)
			.method_46431();

		// Issues button
		this.issuesButton = class_4185.method_46430(ModMenuScreenTexts.ISSUES, button -> {
				final Mod mod = Objects.requireNonNull(selected).getMod();
				boolean isMinecraft = selected.getMod().getId().equals("minecraft");

				if (isMinecraft) {
					class_407.method_61034(this, class_8216.field_43125, true);
				} else {
					var url = mod.getIssueTracker();
					class_407.method_60866(this, url, false);
				}
			})
			.method_46433(this.rightPaneX + urlButtonWidths + 4 + (urlButtonWidths / 2) - (cappedButtonWidth / 2),
				RIGHT_PANE_Y + 36
			)
			.method_46437(Math.min(urlButtonWidths, 200), 20)
			.method_46431();

		// Description list
		this.descriptionListWidget = new DescriptionListWidget(this.field_22787,
			this.paneWidth,
			this.field_22790 - RIGHT_PANE_Y - 96,
			RIGHT_PANE_Y + 60,
			field_22793.field_2000 + 1,
			this
		);
		this.descriptionListWidget.method_46421(this.rightPaneX);

		// Mods folder button
		this.modsFolderButton = class_4185.method_46430(ModMenuScreenTexts.MODS_FOLDER, button -> {
			class_156.method_668().method_673(FabricLoader.getInstance().getGameDir().resolve("mods").toUri());
		}).method_46433(this.field_22789 / 2 - 154, this.field_22790 - 28).method_46437(150, 20).method_46431();

		// Done button
		this.doneButton = class_4185.method_46430(class_5244.field_24334, button -> {
			field_22787.method_1507(previousScreen);
		}).method_46433(this.field_22789 / 2 + 4, this.field_22790 - 28).method_46437(150, 20).method_46431();

		// Initialize data
		modList.reloadFilters();
		this.setFilterOptionsShown(this.keepFilterOptionsShown && this.filterOptionsShown);

		// Add children
		this.method_25429(this.searchBox);
		this.method_48265(this.searchBox);

		if (this.filtersButton != null) {
			this.method_37063(this.filtersButton);
		}

		this.method_37063(this.sortingButton);
		this.method_37063(this.librariesButton);
		this.method_25429(this.modList);

		if (this.configureButton != null) {
			this.method_37063(this.configureButton);
		}

		this.method_37063(this.websiteButton);
		this.method_37063(this.issuesButton);
		this.method_25429(this.descriptionListWidget);
		this.method_37063(this.modsFolderButton);
		this.method_37063(this.doneButton);

		this.init = true;
		this.keepFilterOptionsShown = true;
	}

	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers) {
		return super.method_25404(keyCode, scanCode, modifiers) ||
			this.searchBox.method_25404(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean method_25400(char chr, int keyCode) {
		return this.searchBox.method_25400(chr, keyCode);
	}

	@Override
	public void method_25394(class_332 DrawContext, int mouseX, int mouseY, float delta) {
		super.method_25394(DrawContext, mouseX, mouseY, delta);
		ModListEntry selectedEntry = selected;
		if (selectedEntry != null) {
			this.descriptionListWidget.method_25394(DrawContext, mouseX, mouseY, delta);
		}
		this.modList.method_25394(DrawContext, mouseX, mouseY, delta);
		this.searchBox.method_25394(DrawContext, mouseX, mouseY, delta);
		RenderSystem.disableBlend();
		DrawContext.method_27534(this.field_22793, this.field_22785, this.modList.method_25368() / 2, 8, 16777215);
		if (!ModMenuConfig.DISABLE_DRAG_AND_DROP.getValue()) {
			DrawContext.method_27534(this.field_22793,
				ModMenuScreenTexts.DROP_INFO_LINE_1,
				this.field_22789 - this.modList.method_25368() / 2,
				RIGHT_PANE_Y / 2 - field_22787.field_1772.field_2000 - 1,
				class_124.field_1080.method_532()
			);
			DrawContext.method_27534(this.field_22793,
				ModMenuScreenTexts.DROP_INFO_LINE_2,
				this.field_22789 - this.modList.method_25368() / 2,
				RIGHT_PANE_Y / 2 + 1,
				class_124.field_1080.method_532()
			);
		}
		if (!ModMenuConfig.CONFIG_MODE.getValue()) {
			class_2561 fullModCount = this.computeModCountText(true);
			if (!ModMenuConfig.CONFIG_MODE.getValue() && this.updateFiltersX()) {
				if (this.filterOptionsShown) {
					if (!ModMenuConfig.SHOW_LIBRARIES.getValue() ||
						field_22793.method_27525(fullModCount) <= this.filtersX - 5) {
						DrawContext.method_51430(field_22793,
							fullModCount.method_30937(),
							this.searchBoxX,
							52,
							0xFFFFFF,
							true
						);
					} else {
						DrawContext.method_51430(field_22793,
							computeModCountText(false).method_30937(),
							this.searchBoxX,
							46,
							0xFFFFFF,
							true
						);
						DrawContext.method_51430(field_22793,
							computeLibraryCountText().method_30937(),
							this.searchBoxX,
							57,
							0xFFFFFF,
							true
						);
					}
				} else {
					if (!ModMenuConfig.SHOW_LIBRARIES.getValue() ||
						field_22793.method_27525(fullModCount) <= modList.method_25368() - 5) {
						DrawContext.method_51430(field_22793,
							fullModCount.method_30937(),
							this.searchBoxX,
							52,
							0xFFFFFF,
							true
						);
					} else {
						DrawContext.method_51430(field_22793,
							computeModCountText(false).method_30937(),
							this.searchBoxX,
							46,
							0xFFFFFF,
							true
						);
						DrawContext.method_51430(field_22793,
							computeLibraryCountText().method_30937(),
							this.searchBoxX,
							57,
							0xFFFFFF,
							true
						);
					}
				}
			}
		}
		if (selectedEntry != null) {
			Mod mod = selectedEntry.getMod();
			int x = this.rightPaneX;
			if ("java".equals(mod.getId())) {
				DrawingUtil.drawRandomVersionBackground(mod, DrawContext, x, RIGHT_PANE_Y, 32, 32);
			}
			RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
			RenderSystem.enableBlend();
			DrawContext.method_25290(this.selected.getIconTexture(), x, RIGHT_PANE_Y, 0.0F, 0.0F, 32, 32, 32, 32);
			RenderSystem.disableBlend();
			int lineSpacing = field_22793.field_2000 + 1;
			int imageOffset = 36;
			class_2561 name = class_2561.method_43470(mod.getTranslatedName());
			class_5348 trimmedName = name;
			int maxNameWidth = this.field_22789 - (x + imageOffset);
			if (field_22793.method_27525(name) > maxNameWidth) {
				class_5348 ellipsis = class_5348.method_29430("...");
				trimmedName = class_5348.method_29433(field_22793.method_1714(name,
					maxNameWidth - field_22793.method_27525(ellipsis)
				), ellipsis);
			}
			DrawContext.method_51430(field_22793,
				class_2477.method_10517().method_30934(trimmedName),
				x + imageOffset,
				RIGHT_PANE_Y + 1,
				0xFFFFFF,
				true
			);
			if (mouseX > x + imageOffset && mouseY > RIGHT_PANE_Y + 1 &&
				mouseY < RIGHT_PANE_Y + 1 + field_22793.field_2000 &&
				mouseX < x + imageOffset + field_22793.method_27525(trimmedName)) {
				this.method_47415(ModMenuScreenTexts.modIdTooltip(mod.getId()));
			}
			if (this.init || modBadgeRenderer == null || modBadgeRenderer.getMod() != mod) {
				modBadgeRenderer = new ModBadgeRenderer(
					x + imageOffset + this.field_22787.field_1772.method_27525(trimmedName) + 2,
					RIGHT_PANE_Y,
					field_22789 - 28,
					selectedEntry.mod,
					this
				);
				this.init = false;
			}
			if (!ModMenuConfig.HIDE_BADGES.getValue()) {
				modBadgeRenderer.draw(DrawContext, mouseX, mouseY);
			}
			if (mod.isReal()) {
				DrawContext.method_51433(field_22793,
					mod.getPrefixedVersion(),
					x + imageOffset,
					RIGHT_PANE_Y + 2 + lineSpacing,
					0x808080,
					true
				);
			}
			String authors;
			List<String> names = mod.getAuthors();

			if (!names.isEmpty()) {
				if (names.size() > 1) {
					authors = Joiner.on(", ").join(names);
				} else {
					authors = names.get(0);
				}
				DrawingUtil.drawWrappedString(DrawContext,
					class_1074.method_4662("modmenu.authorPrefix", authors),
					x + imageOffset,
					RIGHT_PANE_Y + 2 + lineSpacing * 2,
					this.paneWidth - imageOffset - 4,
					1,
					0x808080
				);
			}
		}
	}

	private class_2561 computeModCountText(boolean includeLibs) {
		int[] rootMods = formatModCount(ModMenu.ROOT_MODS.values()
			.stream()
			.filter(mod -> !mod.isHidden() && !mod.getBadges().contains(Mod.Badge.LIBRARY))
			.map(Mod::getId)
			.collect(Collectors.toSet()));

		if (includeLibs && ModMenuConfig.SHOW_LIBRARIES.getValue()) {
			int[] rootLibs = formatModCount(ModMenu.ROOT_MODS.values()
				.stream()
				.filter(mod -> !mod.isHidden() && mod.getBadges().contains(Mod.Badge.LIBRARY))
				.map(Mod::getId)
				.collect(Collectors.toSet()));
			return TranslationUtil.translateNumeric("modmenu.showingModsLibraries", rootMods, rootLibs);
		} else {
			return TranslationUtil.translateNumeric("modmenu.showingMods", rootMods);
		}
	}

	private class_2561 computeLibraryCountText() {
		if (ModMenuConfig.SHOW_LIBRARIES.getValue()) {
			int[] rootLibs = formatModCount(ModMenu.ROOT_MODS.values()
				.stream()
				.filter(mod -> !mod.isHidden() && mod.getBadges().contains(Mod.Badge.LIBRARY))
				.map(Mod::getId)
				.collect(Collectors.toSet()));
			return TranslationUtil.translateNumeric("modmenu.showingLibraries", rootLibs);
		} else {
			return class_2561.method_43470(null);
		}
	}

	private int[] formatModCount(Set<String> set) {
		int visible = this.modList.getDisplayedCountFor(set);
		int total = set.size();
		if (visible == total) {
			return new int[]{ total };
		}
		return new int[]{ visible, total };
	}

	@Override
	public void method_25419() {
		this.modList.close();
		this.field_22787.method_1507(this.previousScreen);
	}

	private void setFilterOptionsShown(boolean filterOptionsShown) {
		this.filterOptionsShown = filterOptionsShown;

		this.sortingButton.field_22764 = filterOptionsShown;
		this.librariesButton.field_22764 = filterOptionsShown;
	}

	public ModListEntry getSelectedEntry() {
		return selected;
	}

	public void updateSelectedEntry(ModListEntry entry) {
		if (entry != null) {
			this.selected = entry;
			String modId = selected.getMod().getId();

			if (this.configureButton != null) {

				this.configureButton.field_22763 = modHasConfigScreen.get(modId);
				this.configureButton.field_22764 =
					selected != null && modHasConfigScreen.get(modId) || modScreenErrors.containsKey(modId);

				if (modScreenErrors.containsKey(modId)) {
					Throwable e = modScreenErrors.get(modId);
					this.configureButton.method_47400(class_7919.method_47407(ModMenuScreenTexts.configureError(modId, e)));
				} else {
					this.configureButton.method_47400(class_7919.method_47407(ModMenuScreenTexts.CONFIGURE));
				}
			}

			var isMinecraft = modId.equals("minecraft");

			if (isMinecraft) {
				this.websiteButton.method_25355(SEND_FEEDBACK_TEXT);
				this.issuesButton.method_25355(REPORT_BUGS_TEXT);
			} else {
				this.websiteButton.method_25355(ModMenuScreenTexts.WEBSITE);
				this.issuesButton.method_25355(ModMenuScreenTexts.ISSUES);
			}

			this.websiteButton.field_22764 = true;
			this.websiteButton.field_22763 = isMinecraft || selected.getMod().getWebsite() != null;

			this.issuesButton.field_22764 = true;
			this.issuesButton.field_22763 = isMinecraft || selected.getMod().getIssueTracker() != null;
		}
	}

	public double getScrollPercent() {
		return scrollPercent;
	}

	public void updateScrollPercent(double scrollPercent) {
		this.scrollPercent = scrollPercent;
	}

	public String getSearchInput() {
		return this.searchBox.method_1882();
	}

	private boolean updateFiltersX() {
		if ((this.filtersWidth + field_22793.method_27525(this.computeModCountText(true)) + 20) >= this.searchRowWidth &&
			((this.filtersWidth + field_22793.method_27525(computeModCountText(false)) + 20) >= this.searchRowWidth ||
				(this.filtersWidth + field_22793.method_27525(this.computeLibraryCountText()) + 20) >= this.searchRowWidth
			)) {
			this.filtersX = this.paneWidth / 2 - this.filtersWidth / 2;
			return !filterOptionsShown;
		} else {
			this.filtersX = this.searchRowWidth - this.filtersWidth + 1;
			return true;
		}
	}

	@Override
	public void method_29638(List<Path> paths) {
		Path modsDirectory = FabricLoader.getInstance().getGameDir().resolve("mods");

		// Filter out none mods
		List<Path> mods = paths.stream().filter(ModsScreen::isFabricMod).collect(Collectors.toList());

		if (mods.isEmpty()) {
			return;
		}

		String modList = mods.stream().map(Path::getFileName).map(Path::toString).collect(Collectors.joining(", "));

		this.field_22787.method_1507(new class_410((value) -> {
			if (value) {
				boolean allSuccessful = true;

				for (Path path : mods) {
					try {
						Files.copy(path, modsDirectory.resolve(path.getFileName()));
					} catch (IOException e) {
						LOGGER.warn("Failed to copy mod from {} to {}",
							path,
							modsDirectory.resolve(path.getFileName())
						);
						class_370.method_29627(field_22787, path.toString());
						allSuccessful = false;
						break;
					}
				}

				if (allSuccessful) {
					class_370.method_27024(field_22787.method_1566(),
						class_370.class_9037.field_47588,
						ModMenuScreenTexts.DROP_SUCCESSFUL_LINE_1,
						ModMenuScreenTexts.DROP_SUCCESSFUL_LINE_1
					);
				}
			}
			this.field_22787.method_1507(this);
		}, ModMenuScreenTexts.DROP_CONFIRM, class_2561.method_43470(modList)));
	}

	private static boolean isFabricMod(Path mod) {
		try (JarFile jarFile = new JarFile(mod.toFile())) {
			return jarFile.getEntry("fabric.mod.json") != null;
		} catch (IOException e) {
			return false;
		}
	}

	public Map<String, Boolean> getModHasConfigScreen() {
		return this.modHasConfigScreen;
	}
}
