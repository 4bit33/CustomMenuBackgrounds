package com.terraformersmc.modmenu.config.option;

import net.minecraft.class_7172;

public interface OptionConvertable {
	class_7172<?> asOption();
}
